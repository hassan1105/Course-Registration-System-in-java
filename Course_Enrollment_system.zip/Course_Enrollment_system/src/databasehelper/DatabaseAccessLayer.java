package databasehelper;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.print.attribute.standard.PrinterIsAcceptingJobs;
import javax.swing.JOptionPane;

import model.Course;
import model.CourseAssignment;
import model.User;

public class DatabaseAccessLayer {

	private Connection connect = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    
    private String _localHost="localhost";//127.0.0.1
    private String _databasename="courseenrollsysdb";
    private String _username="root";
    private String _password="1234";
    
    public void OpenConnection()
    {
    	try {
            // This will load the MySQL driver, each DB has its own driver
         //   Class.forName("com.mysql.jdbc.Driver");
            // Setup the connection with the DB
            connect = DriverManager
                    .getConnection("jdbc:mysql://localhost/"+_databasename+"?"
                            + "user="+_username+"&password="+_password);
            
            System.out.println("Connection Opened");
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }

    public boolean isUnique(String _argColParam,String _argValueParam)
    {
    	boolean _isUniqueFlag = true;
    	
    	String query="SELECT * FROM courseenrollsysdb.users where "+_argColParam+"='"+_argValueParam+"'"; //?= ?";
    	
    	try
    	{
    		preparedStatement = connect.prepareStatement(query);
    		//preparedStatement.setString(1, _argColParam);
    		//preparedStatement.setString(2, _argValueParam);
    		
    		resultSet = preparedStatement.executeQuery();
    		
    		//if(resultSet.next())
    		//{
    		//statement = connect.createStatement();
            // Result set get the result of the SQL query
            //resultSet = statement
              //      .executeQuery("select * from courseenrollsysdb.users where "+_argColParam+"='"+_argValueParam+"'");


            if(resultSet!=null)
            {
            	while (resultSet.next()) {
    			_isUniqueFlag=false;
            	}
    		}
    	}
    	catch(Exception ex)
    	{
    		return _isUniqueFlag;
    	}

    	return _isUniqueFlag;
    }
    
    public void SaveData()
    {
/*    	// Statements allow to issue SQL queries to the database
        statement = connect.createStatement();
        // Result set get the result of the SQL query
        resultSet = statement
                .executeQuery("select * from courseenrollsysdb.users");


        if(resultSet!=null)
        {
        	while (resultSet.next()) {
                String userid = resultSet.getString("user_id");
                String firstname = resultSet.getString("FirstName");
                String lastname = resultSet.getString("LastName");
                String Contact_no= resultSet.getString("ContactNo");
                String email = resultSet.getString("Email");
                System.out.println("User: " + userid);
                System.out.println("firstname: " + firstname);
                System.out.println("lastname: " + lastname);
                System.out.println("Contact_no: " + Contact_no);
                System.out.println("email: " + email);
            }
        }
  */  }

	public int SaveUser(String fname, String lname, String email, String contact, String password, String dob,
			String address, String usertype, String cnicEnroll) {
		// TODO Auto-generated method stub
		
		String query="INSERT INTO courseenrollsysdb.users(FirstName, LastName, Email, ContactNo, UserType, IsActive, RegisterDate, CNICEnrollmentNo, Password, DOB, Address) "+
					 " values (?,?,?,?,?,?,CURDATE(),?,?,?,?)";
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setString(1, fname);
			preparedStatement.setString(2, lname);
			preparedStatement.setString(3, email);
			preparedStatement.setString(4, contact);
			preparedStatement.setString(5, usertype);
			preparedStatement.setBoolean(6, false);
			preparedStatement.setString(7, cnicEnroll);
			preparedStatement.setString(8, password);
			preparedStatement.setString(9, dob);
			preparedStatement.setString(10, address);

			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}

		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}

	public boolean IsUserAuthenticated(String email, String password) {
		// TODO Auto-generated method stub
		
		try
		{
			String query="SELECT * FROM courseenrollsysdb.users WHERE EMAIL=? AND PASSWORD=? AND ISACTIVE=1";
			
			preparedStatement = connect.prepareStatement(query);
		
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
		
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				while(resultSet.next())
				{
					return true;
				}
			}
		}
		catch(Exception ex)
		{
			return false;
		}
		
		return false;
	}

	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub

		try
		{
			User model = new User();
			
			String query="SELECT * FROM courseenrollsysdb.users WHERE EMAIL=?";
			
			preparedStatement = connect.prepareStatement(query);
			preparedStatement.setString(1, email);
		
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				while(resultSet.next())
				{
					model.setUser_ID(resultSet.getInt("User_ID") );
					model.setFirstName( resultSet.getString("FirstName"));
					model.setLastName( resultSet.getString("LastName"));
					model.setEmail( resultSet.getString("Email"));
					model.setContactNo( resultSet.getString("ContactNo"));
					model.setAddress( resultSet.getString("Address"));
					model.setCNICEnrollmentNo( resultSet.getString("CNICEnrollmentNo"));
					model.setDOB( resultSet.getDate("DOB"));
					model.setIsActive( resultSet.getBoolean("IsActive"));
					model.setPassword( resultSet.getString("Password"));
					model.setRegisterDate( resultSet.getDate("RegisterDate"));
					model.setUserType( resultSet.getString("UserType"));
					
					return model;
				}
			}
		}
		catch(Exception ex)
		{
			return null;
		}
		
		return null;
	}

	public void CloseConnection() {
		// TODO Auto-generated method stub
		try {
			if(!connect.isClosed())
			{
				connect.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage().toString());
		}
	}

	public int UpdateUser(User loggedInUser) {
		// TODO Auto-generated method stub

		String query="UPDATE courseenrollsysdb.users SET FirstName=?, LastName=?, Email=?, ContactNo=?, CNICEnrollmentNo=?, Password=?, DOB=?, Address=? WHERE User_ID=? ";
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setString(1, loggedInUser.getFirstName());
			preparedStatement.setString(2, loggedInUser.getLastName());
			preparedStatement.setString(3, loggedInUser.getEmail());
			preparedStatement.setString(4, loggedInUser.getContactNo());
			preparedStatement.setString(5, loggedInUser.getCNICEnrollmentNo());
			preparedStatement.setString(6, loggedInUser.getPassword());
			preparedStatement.setDate(7, (Date) loggedInUser.getDOB());
			preparedStatement.setString(8, loggedInUser.getAddress());
			preparedStatement.setInt(9, loggedInUser.getUser_ID());

			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}
/*
	public String[] getUserTableColumns(String usertype) {
		// TODO Auto-generated method stub

		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.users WHERE IsActive = 1 AND UserType=?");
			
			preparedStatement.setString(1, usertype);
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ResultSetMetaData metadata=resultSet.getMetaData();
				int noOfCols = metadata.getColumnCount();
				String columns[]=new String[noOfCols];
				for(int i=1;i<=noOfCols;i++)
				{
					columns[i-1]=metadata.getColumnName(i);
				}
				
				return columns;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
	}
	*/
	public ArrayList<User> getUserList(String usertype) {
		// TODO Auto-generated method stub

		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.users WHERE IsActive = 0 AND UserType ='"+usertype+"'");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<User> userlist = new ArrayList<User>();
				
				while(resultSet.next())
				{
					User model = new User();

					model.setUser_ID(resultSet.getInt("User_ID") );
					model.setFirstName( resultSet.getString("FirstName"));
					model.setLastName( resultSet.getString("LastName"));
					model.setEmail( resultSet.getString("Email"));
					model.setContactNo( resultSet.getString("ContactNo"));
					model.setAddress( resultSet.getString("Address"));
					model.setCNICEnrollmentNo( resultSet.getString("CNICEnrollmentNo"));
					model.setDOB( resultSet.getDate("DOB"));
					model.setIsActive( resultSet.getBoolean("IsActive"));
					model.setPassword( resultSet.getString("Password"));
					model.setRegisterDate( resultSet.getDate("RegisterDate"));
					model.setUserType( resultSet.getString("UserType"));
					
					userlist.add(model);
				}
				
				return userlist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
	}

	public int ApproveUserRequest(String value) {
		// TODO Auto-generated method stub
		
		String query="UPDATE courseenrollsysdb.users SET IsActive=1 WHERE User_ID=? ";
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setInt(1, Integer.parseInt(value));

			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}

	public int SaveCourse(Course model) {
		// TODO Auto-generated method stub
		
		String query="INSERT INTO courseenrollsysdb.course(CourseCode, Name, CreditHrs, Description, AddedBy, AddedDate) "+
				 " values (?,?,?,?,?,CURDATE())";
	
	try
	{
		preparedStatement = connect.prepareStatement(query);
		
		preparedStatement.setString(1, model.getCourseCode());
		preparedStatement.setString(2, model.getName());
		preparedStatement.setString(3, model.getCreditHrs());
		preparedStatement.setString(4, model.getDescription());
		preparedStatement.setInt(5, model.getAddedBy());

		if(preparedStatement.executeUpdate()>0)
		{
			return 1;
		}
	}
	catch(Exception ex)
	{
		System.out.println(ex.getMessage().toString());
		return -1;
	}
	return -1;
	}

	public ArrayList<Course> getCourseList() {
		// TODO Auto-generated method stub

		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.course ");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<Course> courselist = new ArrayList<Course>();
				
				while(resultSet.next())
				{
					Course model = new Course();

					model.setCourseCode(resultSet.getString("CourseCode") );
					model.setName(resultSet.getString("Name"));
					model.setCreditHrs( resultSet.getString("CreditHrs"));
					model.setDescription(resultSet.getString("Description"));
					model.setAddedBy( resultSet.getInt("AddedBy"));
					model.setAddedDate(resultSet.getDate("AddedDate"));
					
					courselist.add(model);
				}
				
				return courselist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}

	public Course getCourseByCode(String _coursecode) {
		// TODO Auto-generated method stub
		
		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.course WHERE CourseCode='"+_coursecode+"'");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{	
				if(resultSet.next())
				{
					Course model = new Course();

					model.setCourseCode(resultSet.getString("CourseCode") );
					model.setName(resultSet.getString("Name"));
					model.setCreditHrs( resultSet.getString("CreditHrs"));
					model.setDescription(resultSet.getString("Description"));
					model.setAddedBy( resultSet.getInt("AddedBy"));
					model.setAddedDate(resultSet.getDate("AddedDate"));
				
					return model;
				}
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}

	public int EditCourse(Course model) {
		// TODO Auto-generated method stub		
		String query="UPDATE courseenrollsysdb.course SET Name=?, CreditHrs=?, Description=? WHERE CourseCode=? ";
	
		try
		{
			preparedStatement = connect.prepareStatement(query);
			preparedStatement.setString(1, model.getName());
			preparedStatement.setString(2, model.getCreditHrs());
			preparedStatement.setString(3, model.getDescription());
			preparedStatement.setString(4, model.getCourseCode());
	
			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		
		return -1;
	}

	public int DeleteCourse(Course model) {
		// TODO Auto-generated method stub
		
		String query="DELETE FROM courseenrollsysdb.course WHERE CourseCode=?";
	
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setString(1, model.getCourseCode());
			
			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null, ex);
			return -1;
		}
		return -1;
	}


	public ArrayList<User> getAllUserList(String usertype) {
		// TODO Auto-generated method stub

		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.users WHERE IsActive = 1 AND UserType ='"+usertype+"'");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<User> userlist = new ArrayList<User>();
				
				while(resultSet.next())
				{
					User model = new User();

					model.setUser_ID(resultSet.getInt("User_ID") );
					model.setFirstName( resultSet.getString("FirstName"));
					model.setLastName( resultSet.getString("LastName"));
					model.setEmail( resultSet.getString("Email"));
					model.setContactNo( resultSet.getString("ContactNo"));
					model.setAddress( resultSet.getString("Address"));
					model.setCNICEnrollmentNo( resultSet.getString("CNICEnrollmentNo"));
					model.setDOB( resultSet.getDate("DOB"));
					model.setIsActive( resultSet.getBoolean("IsActive"));
					model.setPassword( resultSet.getString("Password"));
					model.setRegisterDate( resultSet.getDate("RegisterDate"));
					model.setUserType( resultSet.getString("UserType"));
					
					userlist.add(model);
				}
				
				return userlist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
	}

	
	public User getUserModel(String _argvalue) {
		// TODO Auto-generated method stub

		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.users WHERE Email='"+_argvalue+"' or  CNICEnrollmentNo='"+_argvalue+"'");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{	
				if(resultSet.next())
				{
					User model = new User();

					model.setUser_ID(resultSet.getInt("User_ID") );
					model.setFirstName( resultSet.getString("FirstName"));
					model.setLastName( resultSet.getString("LastName"));
					model.setEmail( resultSet.getString("Email"));
					model.setContactNo( resultSet.getString("ContactNo"));
					model.setAddress( resultSet.getString("Address"));
					model.setCNICEnrollmentNo( resultSet.getString("CNICEnrollmentNo"));
					model.setDOB( resultSet.getDate("DOB"));
					model.setIsActive( resultSet.getBoolean("IsActive"));
					model.setPassword( resultSet.getString("Password"));
					model.setRegisterDate( resultSet.getDate("RegisterDate"));
					model.setUserType( resultSet.getString("UserType"));
				
					return model;
				}
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}

	public int DeleteUser(User model) {
		// TODO Auto-generated method stub
		
		String query="DELETE FROM courseenrollsysdb.users WHERE CNICEnrollmentNo=?";
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setString(1, model.getCNICEnrollmentNo());
			
			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}

	public boolean isCourseAlreadySelected(String text, int user_ID,String operation) {
		// TODO Auto-generated method stub
		boolean _isUniqueFlag = false;

    	String query;
		
		if(operation.equals("Assignment"))
		{
			query="SELECT * FROM courseenrollsysdb.courseassignment where CourseID='"+text+"' AND TeacherID="+user_ID;
		}
		else
		{
			query="SELECT * FROM courseenrollsysdb.courseenrollment where CourseID='"+text+"' AND StudentID="+user_ID;
		}
		
    	try
    	{
    		preparedStatement = connect.prepareStatement(query);
    		//preparedStatement.setString(1, _argColParam);
    		//preparedStatement.setString(2, _argValueParam);
    		
    		resultSet = preparedStatement.executeQuery();
    		
    		//if(resultSet.next())
    		//{
    		//statement = connect.createStatement();
            // Result set get the result of the SQL query
            //resultSet = statement
              //      .executeQuery("select * from courseenrollsysdb.users where "+_argColParam+"='"+_argValueParam+"'");


            if(resultSet!=null)
            {
            	while (resultSet.next()) {
    			_isUniqueFlag=true;
            	}
    		}
    	}
    	catch(Exception ex)
    	{
    		return _isUniqueFlag;
    	}

    	return _isUniqueFlag;
	}

	public int SendCourseRequest(String text, int user_ID,String operation) {
		// TODO Auto-generated method stub

		String query;
		
		if(operation.equals("Assignment"))
		{
			query="INSERT INTO courseenrollsysdb.courseassignment(TeacherID,CourseID,Status,AssignedDate) "+
				 " values (?,?,'Pending',CURDATE())";
		}
		else
		{
			query="INSERT INTO courseenrollsysdb.courseenrollment(StudentID,CourseID,Status,EnrollmentDate) "+
					 " values (?,?,'Pending',CURDATE())";
		}
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			preparedStatement.setInt(1, user_ID);
			preparedStatement.setString(2, text);
			
			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}

	public ArrayList<CourseAssignment> getRequestList(String string,int user_id, String adminOperation) {
		// TODO Auto-generated method stub

		try
		{
			if(string.equals("Teacher"))
			{
				preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.courseassignment WHERE Status = 'Pending' AND TeacherID ="+user_id);
			}
			else if(string.equals("Student"))
			{
				preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.courseenrollment WHERE Status = 'Pending' AND StudentID ="+user_id);
			}
			else if(string.equals("SuperAdmin"))
			{
				if(adminOperation.equals("Teacher"))
				{
					preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.courseassignment WHERE Status = 'Pending'");
				}
				else
				{
					preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.courseenrollment WHERE Status = 'Pending' ");
				}
			}


			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<CourseAssignment> userlist = new ArrayList<CourseAssignment>();
				
				while(resultSet.next())
				{
					CourseAssignment model = new CourseAssignment();

					if(string.equals("Teacher"))
					{
						model.setTeacherID(resultSet.getInt("TeacherID") );
						model.setAssignedDate(resultSet.getDate("AssignedDate") );
					}
					else if(string.equals("Student"))
					{
						model.setTeacherID(resultSet.getInt("StudentID") );
						model.setAssignedDate(resultSet.getDate("EnrollmentDate") );
					}
					else 
					{
						if(adminOperation.equals("Teacher"))
						{
							model.setTeacherID(resultSet.getInt("TeacherID") );
							model.setAssignedDate(resultSet.getDate("AssignedDate") );
						}
						else if(adminOperation.equals("Student"))
						{
							model.setTeacherID(resultSet.getInt("StudentID") );
							model.setAssignedDate(resultSet.getDate("EnrollmentDate") );
						}
					}
					
					model.setStatus( resultSet.getString("Status"));
					model.setCourseID( resultSet.getString("CourseID"));
					
					userlist.add(model);
				}
				
				return userlist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
	}


	public int ApproveRequest(String userType, int user_ID, String value, String userid, String adminOperation) {
		// TODO Auto-generated method stub

		String query = null;
		
		if(userType.equals("Teacher"))
		{
			query="UPDATE courseenrollsysdb.courseassignment SET Status='Approved' WHERE TeacherID="+user_ID+" AND CourseID='"+value+"'";
		}
		else if(userType.equals("Student"))
		{
			query="UPDATE courseenrollsysdb.courseenrollment SET Status='Approved' WHERE StudentID="+user_ID+" AND CourseID='"+value+"'";
		}
		else if(userType.equals("SuperAdmin"))
		{
			if(adminOperation.equals("Teacher"))
			{
				query="UPDATE courseenrollsysdb.courseassignment SET Status='Approved' WHERE TeacherID="+userid+" AND CourseID='"+value+"'";
			}
			else if(adminOperation.equals("Student"))
			{
				query="UPDATE courseenrollsysdb.courseenrollment SET Status='Approved' WHERE StudentID="+userid+" AND CourseID='"+value+"'";
			}
		}
		
		try
		{
			preparedStatement = connect.prepareStatement(query);
			
			if(preparedStatement.executeUpdate()>0)
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return -1;
		}
		return -1;
	}

	public ArrayList<Course> getRegEnrolCourseList(String userType, int user_ID) {
		// TODO Auto-generated method stub

		try
		{
			if(userType.equals("Teacher"))
			{
				preparedStatement = connect.prepareStatement("SELECT c.CourseCode,c.Name,c.CreditHrs,c.Description,c.AddedBy,c.AddedDate "+
															"FROM courseenrollsysdb.course c,courseenrollsysdb.courseassignment a "+
															"WHERE c.CourseCode = a. CourseID and a.TeacherID="+user_ID+"  AND a.Status='Approved';" );
			}
			else
			{
				preparedStatement = connect.prepareStatement("SELECT c.CourseCode,c.Name,c.CreditHrs,c.Description,c.AddedBy,c.AddedDate "+
						"FROM courseenrollsysdb.course c,courseenrollsysdb.courseenrollment a "+
						"WHERE c.CourseCode = a. CourseID and a.StudentID="+user_ID+"  AND a.Status='Approved';" );
			}
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<Course> courselist = new ArrayList<Course>();
				
				while(resultSet.next())
				{
					Course model = new Course();

					model.setCourseCode(resultSet.getString("CourseCode"));
					model.setName(resultSet.getString("Name"));
					model.setCreditHrs( resultSet.getString("CreditHrs"));
					model.setDescription(resultSet.getString("Description"));
					model.setAddedBy( resultSet.getInt("AddedBy"));
					model.setAddedDate(resultSet.getDate("AddedDate"));
					
					courselist.add(model);
				}
				
				return courselist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}

	
	public ArrayList<Course> getAllCourseListByUserType(String userid, String usertype) {
		// TODO Auto-generated method stub
		
		try
		{
			if(usertype.equals("Teacher"))
			{
				preparedStatement = connect.prepareStatement("SELECT c.CourseCode,c.Name,c.CreditHrs,c.Description,c.AddedBy,c.AddedDate " + 
												"FROM courseenrollsysdb.course c,courseenrollsysdb.courseassignment a " +
												"WHERE c.CourseCode = a. CourseID and a.teacherid="+userid+" and a.Status='Approved';" );
			}
			else
			{
				preparedStatement = connect.prepareStatement("SELECT c.CourseCode,c.Name,c.CreditHrs,c.Description,c.AddedBy,c.AddedDate " + 
												"FROM courseenrollsysdb.course c,courseenrollsysdb.courseenrollment a " +
												"WHERE c.CourseCode = a. CourseID and a.StudentID="+userid+" and a.Status='Approved';" );
			}
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{
				ArrayList<Course> courselist = new ArrayList<Course>();
				
				while(resultSet.next())
				{
					Course model = new Course();

					model.setCourseCode(resultSet.getString("CourseCode"));
					model.setName(resultSet.getString("Name"));
					model.setCreditHrs( resultSet.getString("CreditHrs"));
					model.setDescription(resultSet.getString("Description"));
					model.setAddedBy( resultSet.getInt("AddedBy"));
					model.setAddedDate(resultSet.getDate("AddedDate"));
					
					courselist.add(model);
				}
				
				return courselist;
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}

	public User getUserModelByUserType(String email, String usertype) {
		// TODO Auto-generated method stub
		try
		{
			preparedStatement = connect.prepareStatement("SELECT * FROM courseenrollsysdb.users WHERE (Email='"+email+"' or  CNICEnrollmentNo='"+email+"') AND UserType='"+usertype+"'");

			resultSet = preparedStatement.executeQuery();
			
			if(resultSet!=null)
			{	
				if(resultSet.next())
				{
					User model = new User();

					model.setUser_ID(resultSet.getInt("User_ID") );
					model.setFirstName( resultSet.getString("FirstName"));
					model.setLastName( resultSet.getString("LastName"));
					model.setEmail( resultSet.getString("Email"));
					model.setContactNo( resultSet.getString("ContactNo"));
					model.setAddress( resultSet.getString("Address"));
					model.setCNICEnrollmentNo( resultSet.getString("CNICEnrollmentNo"));
					model.setDOB( resultSet.getDate("DOB"));
					model.setIsActive( resultSet.getBoolean("IsActive"));
					model.setPassword( resultSet.getString("Password"));
					model.setRegisterDate( resultSet.getDate("RegisterDate"));
					model.setUserType( resultSet.getString("UserType"));
				
					return model;
				}
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage().toString());
			return null;
		}
		
		return null;
		
	}


}
