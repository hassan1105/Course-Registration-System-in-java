package validationhelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class ValidationHelper {

	public static Boolean isString(String value) 	//value=hassan
	{
		if (value == null) //	hassan ==null	false
		{
			return false;
		}

		int length = value.length();	//length =  6

		for (int i = 0; i < length; i++) //	i =1	1 < 6
		{
			if ((Character.isLetter(value.charAt(i)) == false)) 	//	
	        {
	        	return false;
	        }
	     }

		return true;
		
	}
	
	public static  Boolean isNumber(String value) 	//value=123456
	{
		if (value == null) //	hassan ==null	false
		{
			return false;
		}

		int length = value.length();	//length =  6

		for (int i = 0; i < length; i++) //	i =1	1 < 6
		{
			if ((Character.isDigit(value.charAt(i)) == false)) 	//	
	        {
	        	return false;
	        }
	     }

		return true;
		
	}
	
	//check password length min 8
	//check containing special char
	//check containing char 
	//check containing number
	public static Boolean isValidPassword(String value) 	//value=123456
	{
		if (value == null) //	hassan ==null	false
		{
			return false;
		}

		int length = value.length();	//length =  6

		if(length<8)
		{
			return false;
		}
		
		boolean ischar=false;
		boolean isSpecialChar=false;
		boolean isNumber=false;
		
		for (int i = 0; i < length; i++) //	i =1	1 < 6
		{
			if ((Character.isDigit(value.charAt(i)))) 		
	        {
	        	isNumber=true;
	        }
			else if ((Character.isLetter(value.charAt(i)))) 		
	        {
	        	ischar=true;
	        }
			else
	        {
	        	isSpecialChar=true;
	        }
	     }

		if(isNumber ==true && ischar==true && isSpecialChar==true)
		{
			return true;
		}
		
		return false;
		
	}

	public static boolean isValidEmail(String email) 
    { 
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; 
                              
        Pattern pat = Pattern.compile(emailRegex); 


        if (email == null) 
        {
            return false; 
        }
        
        return pat.matcher(email).matches(); 
    } 

	public  static boolean isValidDate(String date)
	{
		DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        format.setLenient(false);

        try {
            
        	format.parse(date);
            return true;
        } catch (ParseException e) 
        {
        	return false;
        }
	}
}
