package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;


	public class EditDeleteStudentFrm extends JFrame {
		
		private JTextArea txtaddress;
		private JPanel contentPane;
		private JTextField txtfname;
		private JTextField txtlname;
		private JTextField txtcontact;
		private JTextField txtemail;
		private JTextField txtpassword;
		private JTextField txtdob;
		private JTextField txtcnic;
		private JTextField txtsearch;
		public static String Operation;
		public static EditDeleteStudentFrm frame;
		private User model;
		
		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						frame = new EditDeleteStudentFrm();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		public EditDeleteStudentFrm() {
			setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(100, 100, 626, 525);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JPanel panel = new JPanel();
			panel.setBackground(new Color(0, 204, 204));
			panel.setLayout(null);
			panel.setBorder(new EmptyBorder(5, 5, 5, 5));
			panel.setBounds(0, 0, 611, 482);
			contentPane.add(panel);
			
			JLabel lblRegisterNewStudent = new JLabel("Register New Student below");
			lblRegisterNewStudent.setHorizontalAlignment(SwingConstants.CENTER);
			lblRegisterNewStudent.setFont(new Font("Arial", Font.BOLD, 32));
			lblRegisterNewStudent.setBounds(77, 13, 465, 53);
			panel.add(lblRegisterNewStudent);
			
			JSeparator separator = new JSeparator();
			separator.setBounds(12, 67, 585, 17);
			panel.add(separator);
			
			JLabel label_1 = new JLabel("First Name");
			label_1.setFont(new Font("Arial", Font.PLAIN, 15));
			label_1.setBounds(12, 145, 82, 16);
			panel.add(label_1);
			
			txtfname = new JTextField();
			txtfname.setText((String) null);
			txtfname.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtfname.setColumns(10);
			txtfname.setBounds(12, 162, 273, 22);
			panel.add(txtfname);
			
			JLabel label_2 = new JLabel("Last Name");
			label_2.setFont(new Font("Arial", Font.PLAIN, 15));
			label_2.setBounds(297, 145, 82, 16);
			panel.add(label_2);
			
			txtlname = new JTextField();
			txtlname.setText((String) null);
			txtlname.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtlname.setColumns(10);
			txtlname.setBounds(297, 162, 299, 22);
			panel.add(txtlname);
			
			JLabel label_3 = new JLabel("Contact No");
			label_3.setFont(new Font("Arial", Font.PLAIN, 15));
			label_3.setBounds(297, 205, 82, 16);
			panel.add(label_3);
			
			txtcontact = new JTextField();
			txtcontact.setText((String) null);
			txtcontact.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtcontact.setColumns(10);
			txtcontact.setBounds(297, 222, 299, 22);
			panel.add(txtcontact);
			
			JLabel label_4 = new JLabel("Email");
			label_4.setFont(new Font("Arial", Font.PLAIN, 15));
			label_4.setBounds(12, 205, 82, 16);
			panel.add(label_4);
			
			txtemail = new JTextField();
			txtemail.setText((String) null);
			txtemail.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtemail.setColumns(10);
			txtemail.setBounds(12, 222, 273, 22);
			panel.add(txtemail);
			
			JLabel label_5 = new JLabel("Password");
			label_5.setFont(new Font("Arial", Font.PLAIN, 15));
			label_5.setBounds(12, 257, 82, 16);
			panel.add(label_5);
			
			txtpassword = new JTextField();
			txtpassword.setText((String) null);
			txtpassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtpassword.setColumns(10);
			txtpassword.setBounds(13, 278, 273, 22);
			panel.add(txtpassword);
			
			JLabel label_6 = new JLabel("DOB ( YYYY/MM/DD)");
			label_6.setFont(new Font("Arial", Font.PLAIN, 15));
			label_6.setBounds(22, 313, 185, 16);
			panel.add(label_6);
			
			txtdob = new JTextField();
			txtdob.setText((String) null);
			txtdob.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtdob.setColumns(10);
			txtdob.setBounds(12, 331, 273, 22);
			panel.add(txtdob);
			
			JLabel label_7 = new JLabel("User Type");
			label_7.setFont(new Font("Arial", Font.PLAIN, 15));
			label_7.setBounds(12, 366, 82, 16);
			panel.add(label_7);
			
			JLabel lblStudent = new JLabel("Student");
			lblStudent.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblStudent.setBounds(106, 366, 138, 31);
			panel.add(lblStudent);
			
			JLabel label_9 = new JLabel("Address");
			label_9.setFont(new Font("Arial", Font.PLAIN, 15));
			label_9.setBounds(297, 313, 82, 16);
			panel.add(label_9);
			
			 txtaddress = new JTextArea();
			txtaddress.setText((String) null);
			txtaddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtaddress.setEditable(false);
			txtaddress.setBounds(297, 331, 300, 53);
			panel.add(txtaddress);
			
			JSeparator separator_1 = new JSeparator();
			separator_1.setBounds(12, 409, 585, 17);
			panel.add(separator_1);
			
			JButton button = new JButton("Reset");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					txtfname.setText("");
					txtlname.setText("");
					txtemail.setText("");
					txtcontact.setText("");
					txtdob.setText("");
					txtaddress.setText("");
					txtpassword.setText("");
					txtcnic.setText("");
					txtsearch.setText("");
					
				}
			});
			button.setFont(new Font("Arial", Font.PLAIN, 15));
			button.setBackground(new Color(153, 255, 255));
			button.setBounds(341, 425, 116, 46);
			panel.add(button);
			
			JButton button_1 = new JButton("Save");
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					if(Operation.equals("Edit"))
					{
						//get all the textfield values and check if every required textfield's value is entered
						model.setAddress(txtaddress.getText().toString());
						model.setCNICEnrollmentNo(txtcnic.getText().toString());
						model.setContactNo(txtcontact.getText());
						model.setDOB(Date.valueOf(txtdob.getText()));
						model.setEmail(txtemail.getText());
						model.setFirstName(txtfname.getText());
						model.setLastName(txtlname.getText());
						model.setPassword(txtpassword.getText());
						String Fname=txtfname.getText();
						String lname=txtlname.getText();
						String email=txtemail.getText();
						String contactNo=txtcontact.getText();
						String Password=txtpassword.getText();
						DatabaseAccessLayer dba=new DatabaseAccessLayer();
						
						dba.OpenConnection();
						
						if(txtfname.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter First Name");
						}
						else if(!ValidationHelper.isString(Fname))
						{
							JOptionPane.showMessageDialog(null, "First Name is Invalid");
						}
						else if(txtlname.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter Last Name");
						}
						else if(!ValidationHelper.isString(lname))
						{
							JOptionPane.showMessageDialog(null, "Last Name is Invalid");
						}
						else if(txtemail.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter Email Address");
						}
						else if(!ValidationHelper.isValidEmail(email))
						{
							JOptionPane.showMessageDialog(null, "Email is Invalid");
						}
						else if(txtcontact.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter Contact Num");
						}
						else if(!ValidationHelper.isNumber(contactNo))
						{
							JOptionPane.showMessageDialog(null, "Contact NO. must be a Numbers");
						}
						else if(txtaddress.getText().toString().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter Address");
						} 
						else if(txtpassword.getText().toString().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter Password");
						}
						else if(!ValidationHelper.isValidPassword(Password))
						{
							JOptionPane.showMessageDialog(null, "Invalid Password! Password must contain Atleast 8 characters, one Digit,one Alphabet and one Special Character must be there to make password strong.");
						}
						else if(txtcnic.getText().toString().equals(""))
						{
							JOptionPane.showMessageDialog(null, "Enter CNIC/ Enrollment No");
						}
						
						else
						{
							int response = dba.UpdateUser(model);
							
							if(response==-1)
							{
								dba.CloseConnection();
								JOptionPane.showMessageDialog(null, "Ooops !!! Something went wrong. Try again please...");
							}
							else
							{
								dba.CloseConnection();
								JOptionPane.showMessageDialog(null, "Student Updated Successfully");
								
								frame.dispose();
							}
						}
						
						dba.CloseConnection();
						
					}
					else
					{
						DatabaseAccessLayer dba=new DatabaseAccessLayer();
						dba.OpenConnection();
						
						int response=dba.DeleteUser(model);
						
						if(response!=-1)
						{
							JOptionPane.showMessageDialog(null, "Student has been Deleted successfully");
							dba.CloseConnection();
							frame.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Ooops! something went wrong please try again later");
						}
						
						dba.CloseConnection();
					}
				}
			});
			button_1.setFont(new Font("Arial", Font.PLAIN, 15));
			button_1.setBackground(new Color(153, 255, 255));
			button_1.setBounds(481, 425, 116, 46);
			panel.add(button_1);
			
			
			if(Operation.equals("Edit"))
			{
				button_1.setText("Update");
				lblRegisterNewStudent.setText("Update Student Record Here");
			}
			else if(Operation.equals("Delete"))
			{
				button_1.setText("Delete");
				lblRegisterNewStudent.setText("Delete Student Record Here");

			} 
							
			
			txtcnic = new JTextField();
			txtcnic.setEditable(false);
			txtcnic.setText((String) null);
			txtcnic.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtcnic.setColumns(10);
			txtcnic.setBounds(297, 278, 299, 22);
			panel.add(txtcnic);
			
			JLabel label_10 = new JLabel("CNIC/ Enrollment No");
			label_10.setFont(new Font("Arial", Font.PLAIN, 15));
			label_10.setBounds(298, 257, 158, 16);
			panel.add(label_10);
			
			JLabel lblSearchByEmail = new JLabel("Search By CNIC / Email");
			lblSearchByEmail.setFont(new Font("Arial", Font.PLAIN, 15));
			lblSearchByEmail.setBounds(12, 79, 320, 16);
			panel.add(lblSearchByEmail);
			
			txtsearch = new JTextField();
			txtsearch.setText((String) null);
			txtsearch.setFont(new Font("Tahoma", Font.PLAIN, 15));
			txtsearch.setColumns(10);
			txtsearch.setBounds(12, 96, 273, 22);
			panel.add(txtsearch);
			
			JButton button_2 = new JButton("Search");
			button_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					

					if(txtsearch.getText().equals(""))
					{
						JOptionPane.showMessageDialog(null, "Enter Student Email to search...");
					}
					else
					{
						DatabaseAccessLayer dba=new DatabaseAccessLayer();
						
						dba.OpenConnection();
						
						model=dba.getUserModelByUserType(txtsearch.getText().toString(),"Student");
								
						if(model!=null)
						{
							txtfname.setText(model.getFirstName());
							txtlname.setText(model.getLastName());
							txtemail.setText(model.getEmail());
							txtcontact.setText(model.getContactNo());
							txtpassword.setText(model.getPassword());
							txtcnic.setText(model.getCNICEnrollmentNo());
							txtdob.setText(model.getDOB().toString());
							txtaddress.setText(model.getAddress());
						}
						else
						{
							JOptionPane.showMessageDialog(null, "No RECORD found. Please try again");
						}
						dba.CloseConnection();
					}
					
				}
			});
			button_2.setFont(new Font("Arial", Font.PLAIN, 15));
			button_2.setBackground(new Color(153, 255, 255));
			button_2.setBounds(465, 79, 116, 46);
			panel.add(button_2);
			
			JSeparator separator_2 = new JSeparator();
			separator_2.setBounds(12, 132, 585, 17);
			panel.add(separator_2);
		}

	}

