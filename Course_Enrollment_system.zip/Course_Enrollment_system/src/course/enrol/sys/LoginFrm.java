package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class LoginFrm extends JFrame {

	private static LoginFrm frame;
	private JPanel contentPane;
	private JTextField txtemail;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new LoginFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 344, 354);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Login");
		label.setFont(new Font("Tahoma", Font.BOLD, 31));
		label.setBounds(114, 13, 97, 46);
		contentPane.add(label);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 84, 303, 1);
		contentPane.add(separator);
		
		JLabel label_1 = new JLabel("Email :");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(12, 98, 80, 25);
		contentPane.add(label_1);
		
		txtemail = new JTextField();
		txtemail.setFont(new Font("Arial", Font.PLAIN, 15));
		txtemail.setColumns(10);
		txtemail.setBounds(12, 120, 307, 24);
		contentPane.add(txtemail);
		
		JLabel label_2 = new JLabel("Password :");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(12, 155, 80, 25);
		contentPane.add(label_2);
		
		txtpassword = new JPasswordField();
		txtpassword.setFont(new Font("Arial", Font.PLAIN, 15));
		txtpassword.setBounds(12, 177, 307, 22);
		contentPane.add(txtpassword);
		
		JButton btnregister = new JButton("Register");
		btnregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				RegisterFrm.main(new String[] {});
				
				frame.dispose();
			}
		});
		btnregister.setFont(new Font("Arial", Font.PLAIN, 15));
		btnregister.setBackground(new Color(153, 255, 255));
		btnregister.setBounds(37, 251, 116, 46);
		contentPane.add(btnregister);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String email=txtemail.getText();
				String password=String.valueOf(txtpassword.getPassword());
				
				if(email.equals(""))
				{
					JOptionPane.showMessageDialog(null,"Email cannnot be empty");
				}
				else if(!ValidationHelper.isValidEmail(email))
				{
					JOptionPane.showMessageDialog(null, "Email is Invlaid");
				}
				else if(password.equals(""))
				{
					JOptionPane.showMessageDialog(null,"Password cannnot be empty");
				}
				else
				{
					
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					dba.OpenConnection();
					
					boolean response = dba.IsUserAuthenticated(email,password);
				
					if(response)
					{
						JOptionPane.showMessageDialog(null, "Welcome to Course Enrollment System");
						
						User _userModel = dba.getUserByEmail(email);
						
						if(_userModel==null)
						{
							JOptionPane.showMessageDialog(null, "Request Not accepted / Invalid Username and Password");
							dba.CloseConnection();
						}
						else
						{
							dba.CloseConnection();
							
							if(_userModel.getUserType().equals("SuperAdmin"))
							{
								DashBoardFrm.loggedInUser = _userModel;
								DashBoardFrm.main(new String[] {});
							}	
							else if(_userModel.getUserType().equals("Teacher"))
							{
								TeacherDashboardFrm.loggedInUser = _userModel;
								TeacherDashboardFrm.main(new String[] {});
							}	
							else if(_userModel.getUserType().equals("Student"))
							{
								StudentDashboard.loggedInUser = _userModel;
								StudentDashboard.main(new String[] {});
							}	
							frame.dispose();
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Request Not accepted / Invalid Username and Password");
						dba.CloseConnection();
					}
				}
				
			}
		});
		btnlogin.setFont(new Font("Arial", Font.PLAIN, 15));
		btnlogin.setBackground(new Color(153, 255, 255));
		btnlogin.setBounds(183, 251, 116, 46);
		contentPane.add(btnlogin);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(16, 219, 303, 1);
		contentPane.add(separator_1);
	}
}
