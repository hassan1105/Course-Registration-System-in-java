package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;

import model.User;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Toolkit;
import java.awt.Color;

public class TeacherDashboardFrm extends JFrame {
	
	public static User loggedInUser;
	public static TeacherDashboardFrm frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new TeacherDashboardFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public TeacherDashboardFrm() {
		getContentPane().setBackground(new Color(0, 204, 204));
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( DashBoard )");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 842, 605);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(153, 255, 255));
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmProfile_1 = new JMenuItem("Profile");
		mntmProfile_1.setBackground(new Color(153, 255, 255));
		mntmProfile_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ProfileFrm.main(new String[] {});
				ProfileFrm.loggedInUser=loggedInUser;
			}
		});
		mnNewMenu.add(mntmProfile_1);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem mntmLogout = new JMenuItem("Logout");
		mntmLogout.setBackground(new Color(153, 255, 255));
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				loggedInUser = null;
				LoginFrm.main(new String[] {});
				
				frame.dispose();
			}
		});
		mnNewMenu.add(mntmLogout);
		
		JSeparator separator_1 = new JSeparator();
		mnNewMenu.add(separator_1);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setBackground(new Color(153, 255, 255));
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmExit);
		
		JMenu mnRequests = new JMenu("Registeration");
		menuBar.add(mnRequests);
		
		JMenuItem mntmCourseEnrollRequests = new JMenuItem("My Registered Course List");
		mntmCourseEnrollRequests.setBackground(new Color(153, 255, 255));
		mntmCourseEnrollRequests.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				MyRegisterCousreList.loggedInUser=loggedInUser;
				MyRegisterCousreList.main(new String[] {});
				
			}
		});
		mnRequests.add(mntmCourseEnrollRequests);
		
		JSeparator separator_2 = new JSeparator();
		mnRequests.add(separator_2);
		
		JMenuItem menuItem_1 = new JMenuItem("Register Course");
		menuItem_1.setBackground(new Color(153, 255, 255));
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				RegisterCourseFrm.LoggedInUser=loggedInUser;
				RegisterCourseFrm.main(new String[] {});
				
			}
		});
		mnRequests.add(menuItem_1);
		
		JMenuItem menuItem = new JMenuItem("Request Status");
		menuItem.setBackground(new Color(153, 255, 255));
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				RequestStatusFrm.loggedInUser=loggedInUser;
				RequestStatusFrm.main(new String[] {});
				
			}
		});
		mnRequests.add(menuItem);
		
		JMenu mnCourse = new JMenu("Course");
		menuBar.add(mnCourse);
		
		JMenuItem mntmViewAllCourses = new JMenuItem("View All Courses");
		mntmViewAllCourses.setBackground(new Color(153, 255, 255));
		mntmViewAllCourses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ViewAllCourseList.main(new String[] {});
				
			}
		});
		mnCourse.add(mntmViewAllCourses);
	}
}
