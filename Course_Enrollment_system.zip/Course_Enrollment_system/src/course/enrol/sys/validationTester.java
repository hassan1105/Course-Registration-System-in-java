package course.enrol.sys;

import validationhelper.ValidationHelper;

public class validationTester extends ValidationHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(isString("Hassan"));
		System.out.println(isNumber("04310054632"));
		System.out.println(isString("Hass@an"));
		System.out.println(isString("Has san"));
		System.out.println(isString("Han"));
	}

}
