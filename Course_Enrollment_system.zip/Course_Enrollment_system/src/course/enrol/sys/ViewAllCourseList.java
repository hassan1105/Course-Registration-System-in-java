package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import databasehelper.DatabaseAccessLayer;
import model.Course;
import model.User;
import java.awt.Color;
import java.awt.Toolkit;

public class ViewAllCourseList extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static ViewAllCourseList frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new ViewAllCourseList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewAllCourseList() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( All Course List )");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1049, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);


		JLabel label = new JLabel("View all course list");
		label.setBackground(new Color(153, 255, 255));
		label.setFont(new Font("Tahoma", Font.BOLD, 31));
		contentPane.add(label, BorderLayout.NORTH);
		
		table = new JTable();//data,column);
		table.setModel(new DefaultTableModel(new Object[][] {
			
		},
				new String[] {
						"CourseCode","Name","CreditHrs","Description","AddedBy","AddedDate"
				}));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		DisplayCourseList();
	}

	private void DisplayCourseList() {
		// TODO Auto-generated method stub
		ArrayList<Course> courselist;
		
		DatabaseAccessLayer dba=new DatabaseAccessLayer();
		dba.OpenConnection();

		courselist=dba.getCourseList();
		
		DefaultTableModel model=(DefaultTableModel)table.getModel();		
		//clear jtable contents
		model.setRowCount(0);		
		Object[] row=new Object[13];
		
		for(int i=0;i<courselist.size();i++)
		{
			row[0]=courselist.get(i).getCourseCode();
			row[1]=courselist.get(i).getName();
			row[2]=courselist.get(i).getCreditHrs();
			row[3]=courselist.get(i).getDescription();
			row[4]=courselist.get(i).getAddedBy();
			row[5]=courselist.get(i).getAddedDate();
			
			model.addRow(row);
		}
		
		dba.CloseConnection();
		
	}

}
