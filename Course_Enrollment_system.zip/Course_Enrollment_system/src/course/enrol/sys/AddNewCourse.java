package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.Course;
import model.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class AddNewCourse extends JFrame {

	
	private JPanel contentPane;
	public static AddNewCourse frame;
	public static User LoggedInUser;
	private JTextField txtCourseCode;
	private JTextField txtName;
	private JTextField txtCreditHrs;
	private JTextField txtDescription;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new AddNewCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddNewCourse() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( Add New Course )");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 633, 361);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCourseRegisteration = new JLabel("Course Registeration");
		lblCourseRegisteration.setHorizontalAlignment(SwingConstants.CENTER);
		lblCourseRegisteration.setFont(new Font("Arial", Font.BOLD, 32));
		lblCourseRegisteration.setBounds(142, 13, 333, 53);
		contentPane.add(lblCourseRegisteration);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel lblCourseCode = new JLabel("Course Code");
		lblCourseCode.setFont(new Font("Arial", Font.PLAIN, 15));
		lblCourseCode.setBounds(12, 109, 103, 16);
		contentPane.add(lblCourseCode);
		
		txtCourseCode = new JTextField();
		txtCourseCode.setColumns(10);
		txtCourseCode.setBounds(12, 126, 273, 22);
		contentPane.add(txtCourseCode);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Arial", Font.PLAIN, 15));
		lblName.setBounds(297, 109, 82, 16);
		contentPane.add(lblName);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(297, 126, 299, 22);
		contentPane.add(txtName);
		
		JLabel lblCreditHrs = new JLabel("Credit Hrs");
		lblCreditHrs.setFont(new Font("Arial", Font.PLAIN, 15));
		lblCreditHrs.setBounds(12, 169, 82, 16);
		contentPane.add(lblCreditHrs);
		
		txtCreditHrs = new JTextField();
		txtCreditHrs.setColumns(10);
		txtCreditHrs.setBounds(12, 186, 273, 22);
		contentPane.add(txtCreditHrs);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setFont(new Font("Arial", Font.PLAIN, 15));
		lblDescription.setBounds(297, 169, 82, 16);
		contentPane.add(lblDescription);
		
		txtDescription = new JTextField();
		txtDescription.setColumns(10);
		txtDescription.setBounds(297, 186, 299, 22);
		contentPane.add(txtDescription);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 235, 585, 17);
		contentPane.add(separator_1);
		
		JButton button_1 = new JButton("Reset");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtCourseCode.setText("");
				txtName.setText("");
				txtCreditHrs.setText("");
				txtDescription.setText("");
			}
		});
		button_1.setFont(new Font("Arial", Font.PLAIN, 15));
		button_1.setBackground(new Color(153, 255, 255));
		button_1.setBounds(341, 251, 116, 46);
		contentPane.add(button_1);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String courseName=txtName.getText();
				String courseCrdit=txtCreditHrs.getText();
				Course model;
				
				if(txtCourseCode.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course code cannot be empty");
				}
				else if(txtName.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course Name cannot be empty");
				}
				else if(!ValidationHelper.isString(courseName))
				{
					JOptionPane.showMessageDialog(null, "Course Name is Invlaid");
				}
				else if(txtCreditHrs.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course credit hours cannot be empty");
				}
				else if(!ValidationHelper.isNumber(courseCrdit))
				{
					JOptionPane.showMessageDialog(null, "Credit Hour must be a Number");
				}
				else if(txtDescription.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Description details are missing");
				}
				else
				{
					model = new Course();
					
					model.setCourseCode(txtCourseCode.getText());
					model.setName(txtName.getText());
					model.setCreditHrs(txtCreditHrs.getText());
					model.setDescription(txtDescription.getText());
					model.setAddedBy(LoggedInUser.getUser_ID());
					
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					int response=dba.SaveCourse(model);
					
					if(response!=-1)
					{
						JOptionPane.showMessageDialog(null, "Course has been registered successfully");
						
						frame.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Ooops! something went wrong please try again later");
					}
					
					dba.CloseConnection();
				}
			}
		});
		btnSave.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSave.setBackground(new Color(153, 255, 255));
		btnSave.setBounds(481, 251, 116, 46);
		contentPane.add(btnSave);
	}

}
