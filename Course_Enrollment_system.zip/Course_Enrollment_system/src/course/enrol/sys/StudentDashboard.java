package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.User;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Toolkit;

public class StudentDashboard extends JFrame {

	private JPanel contentPane;
	public static User loggedInUser;
	public static StudentDashboard frame ;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new StudentDashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public StudentDashboard() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( DashBoard )");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 842, 605);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(153, 255, 255));
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmProfile_1 = new JMenuItem("Profile");
		mntmProfile_1.setBackground(new Color(153, 255, 255));
		mntmProfile_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ProfileFrm.main(new String[] {});
				ProfileFrm.loggedInUser=loggedInUser;
			}
		});
		mnNewMenu.add(mntmProfile_1);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem mntmLogout = new JMenuItem("Logout");
		mntmLogout.setBackground(new Color(153, 255, 255));
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				loggedInUser = null;
				LoginFrm.main(new String[] {});
				
				frame.dispose();
			}
		});
		mnNewMenu.add(mntmLogout);
		
		JSeparator separator_1 = new JSeparator();
		mnNewMenu.add(separator_1);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setBackground(new Color(153, 255, 255));
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmExit);
		
		JMenu mnRequests = new JMenu("Enrollment");
		menuBar.add(mnRequests);
		
		JMenuItem mntmCourseEnrollRequests = new JMenuItem("My Enrolled Course List");
		mntmCourseEnrollRequests.setBackground(new Color(153, 255, 255));
		mntmCourseEnrollRequests.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				MyRegisterCousreList.loggedInUser=loggedInUser;
				MyRegisterCousreList.main(new String[] {});
				
			}
		});
		mnRequests.add(mntmCourseEnrollRequests);
		
		JSeparator separator_6 = new JSeparator();
		mnRequests.add(separator_6);
		
		JMenuItem mntmEnrollCourse = new JMenuItem("Enroll Course");
		mntmEnrollCourse.setBackground(new Color(153, 255, 255));
		mntmEnrollCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				RegisterCourseFrm.LoggedInUser=loggedInUser;
				RegisterCourseFrm.main(new String[] {});
				
			}
		});
		mnRequests.add(mntmEnrollCourse);
		
		JMenuItem mntmRequestStatus = new JMenuItem("Request Status");
		mntmRequestStatus.setBackground(new Color(153, 255, 255));
		mntmRequestStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				RequestStatusFrm.loggedInUser=loggedInUser;
				RequestStatusFrm.main(new String[] {});
				
			}
		});
		mnRequests.add(mntmRequestStatus);
		
		JMenu mnCourse = new JMenu("Course");
		menuBar.add(mnCourse);
		
		JMenuItem mntmViewAllCourses = new JMenuItem("View All Courses");
		mntmViewAllCourses.setBackground(new Color(153, 255, 255));
		mntmViewAllCourses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ViewAllCourseList.main(new String[] {});
				
			}
		});
		mnCourse.add(mntmViewAllCourses);
		
		JMenu mnTeacher = new JMenu("Teacher");
		menuBar.add(mnTeacher);
		
		JMenuItem mntmViewAllTeachers = new JMenuItem("View All Teachers");
		mntmViewAllTeachers.setBackground(new Color(153, 255, 255));
		mntmViewAllTeachers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				AllTeacherListFrm.main(new String[] {});
				
			}
		});
		mnTeacher.add(mntmViewAllTeachers);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
}
