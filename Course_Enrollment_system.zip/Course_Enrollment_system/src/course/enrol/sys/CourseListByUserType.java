package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import databasehelper.DatabaseAccessLayer;
import model.Course;
import model.User;
import java.awt.Toolkit;
import java.awt.Color;

public class CourseListByUserType extends JFrame {

	public static ArrayList<Course> CourseList;
	private JPanel contentPane;
	public static CourseListByUserType frame;
	public static User loggedInUser;
	protected static String UserType;
	private JTable table;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new CourseListByUserType();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CourseListByUserType() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		
		if(UserType.equals("Teacher"))
		{
			setTitle("Course Enrollment System ( Course List )");
		}
		else
		{
			setTitle("Course Enrollment System ( Course List )");
		}
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1049, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);


		JLabel label = new JLabel("View all registered Course list");
		label.setBackground(new Color(0, 204, 204));
		label.setFont(new Font("Tahoma", Font.BOLD, 31));
		contentPane.add(label, BorderLayout.NORTH);
		
		if(UserType.equals("Teacher"))
		{
			label.setText(" Registered Course list By Teacher ");
		}
		else
		{
			label.setText(" Enrolled Course list By Student ");
		}
		
		table = new JTable();//data,column);
		table.setModel(new DefaultTableModel(new Object[][] {
			
		},
				new String[] {
						"CourseCode","Name","CreditHrs","Description","AddedBy","AddedDate"
				}));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		DisplayCourseList();
	}

	private void DisplayCourseList() {
		// TODO Auto-generated method stub
		ArrayList<Course> courselist=CourseList;
		
		DefaultTableModel model=(DefaultTableModel)table.getModel();		
		//clear jtable contents
		model.setRowCount(0);		
		Object[] row=new Object[13];
		
		for(int i=0;i<courselist.size();i++)
		{
			row[0]=courselist.get(i).getCourseCode();
			row[1]=courselist.get(i).getName();
			row[2]=courselist.get(i).getCreditHrs();
			row[3]=courselist.get(i).getDescription();
			row[4]=courselist.get(i).getAddedBy();
			row[5]=courselist.get(i).getAddedDate();
			
			model.addRow(row);
		}
		
	}

}