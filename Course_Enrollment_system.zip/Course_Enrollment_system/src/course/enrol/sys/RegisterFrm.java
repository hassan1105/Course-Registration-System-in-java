package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import validationhelper.ValidationHelper;
import databasehelper.DatabaseAccessLayer;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class RegisterFrm extends JFrame {

	private JRadioButton rdbtnTeacher ;
	private JRadioButton rdbtnStudent ;
	private static RegisterFrm frame;
	private JPanel contentPane;
	private JTextField txtfname;
	private JTextField txtlname;
	private JTextField txtcontactno;
	private JTextField txtemail;
	private JTextField txtpassword;
	private JTextField txtconfirmpass;
	private JTextField txtdob;
	private JTextField txtcnicenroll;
	private JTextArea txtareaaddress ;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new RegisterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( Register )");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 660, 551);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Register Here");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Arial", Font.BOLD, 32));
		label.setBounds(175, 13, 243, 53);
		contentPane.add(label);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel label_1 = new JLabel("Fill the below form to register");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(22, 79, 234, 17);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("First Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(12, 109, 82, 16);
		contentPane.add(label_2);
		
		txtfname = new JTextField();
		txtfname.setColumns(10);
		txtfname.setBounds(12, 126, 273, 22);
		contentPane.add(txtfname);
		
		JLabel label_3 = new JLabel("Last Name");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(297, 109, 82, 16);
		contentPane.add(label_3);
		
		txtlname = new JTextField();
		txtlname.setColumns(10);
		txtlname.setBounds(297, 126, 299, 22);
		contentPane.add(txtlname);
		
		JLabel label_4 = new JLabel("Contact No");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(297, 169, 82, 16);
		contentPane.add(label_4);
		
		txtcontactno = new JTextField();
		txtcontactno.setColumns(10);
		txtcontactno.setBounds(297, 186, 299, 22);
		contentPane.add(txtcontactno);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(12, 186, 273, 22);
		contentPane.add(txtemail);
		
		JLabel label_5 = new JLabel("Email");
		label_5.setFont(new Font("Arial", Font.PLAIN, 15));
		label_5.setBounds(12, 169, 82, 16);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Password");
		label_6.setFont(new Font("Arial", Font.PLAIN, 15));
		label_6.setBounds(12, 221, 82, 16);
		contentPane.add(label_6);
		
		txtpassword = new JTextField();
		txtpassword.setColumns(10);
		txtpassword.setBounds(13, 242, 273, 22);
		contentPane.add(txtpassword);
		
		JLabel label_7 = new JLabel("Re-Type Password");
		label_7.setFont(new Font("Arial", Font.PLAIN, 15));
		label_7.setBounds(297, 221, 134, 16);
		contentPane.add(label_7);
		
		txtconfirmpass = new JTextField();
		txtconfirmpass.setColumns(10);
		txtconfirmpass.setBounds(298, 242, 299, 22);
		contentPane.add(txtconfirmpass);
		
		JLabel label_8 = new JLabel("Address");
		label_8.setFont(new Font("Arial", Font.PLAIN, 15));
		label_8.setBounds(297, 277, 82, 16);
		contentPane.add(label_8);
		
		txtareaaddress = new JTextArea();
		txtareaaddress.setBounds(297, 295, 300, 53);
		contentPane.add(txtareaaddress);
		
		JLabel label_9 = new JLabel("DOB ( YYYY/MM/DD)");
		label_9.setFont(new Font("Arial", Font.PLAIN, 15));
		label_9.setBounds(22, 277, 185, 16);
		contentPane.add(label_9);
		
		txtdob = new JTextField();
		txtdob.setColumns(10);
		txtdob.setBounds(12, 295, 273, 22);
		contentPane.add(txtdob);
		
		JLabel label_10 = new JLabel("CNIC/ Enrollment No");
		label_10.setFont(new Font("Arial", Font.PLAIN, 15));
		label_10.setBounds(299, 375, 158, 16);
		contentPane.add(label_10);
		
		txtcnicenroll = new JTextField();
		txtcnicenroll.setColumns(10);
		txtcnicenroll.setBounds(298, 394, 299, 22);
		contentPane.add(txtcnicenroll);
		
		rdbtnStudent = new JRadioButton("Student");
		rdbtnStudent.setBackground(new Color(0, 204, 204));
		rdbtnStudent.setBounds(153, 395, 127, 25);
		contentPane.add(rdbtnStudent);
		
		rdbtnTeacher = new JRadioButton("Teacher");
		rdbtnTeacher.setBackground(new Color(0, 204, 204));
		rdbtnTeacher.setBounds(22, 395, 127, 25);
		contentPane.add(rdbtnTeacher);
		
		JLabel label_11 = new JLabel("User Type");
		label_11.setFont(new Font("Arial", Font.PLAIN, 15));
		label_11.setBounds(12, 370, 82, 16);
		contentPane.add(label_11);
		
		JButton btnclose = new JButton("Close");
		btnclose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
				
			}
		});
		btnclose.setFont(new Font("Arial", Font.PLAIN, 15));
		btnclose.setBackground(new Color(153, 255, 255));
		btnclose.setBounds(207, 449, 116, 46);
		contentPane.add(btnclose);
		
		JButton btnreset = new JButton("Reset");
		btnreset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtfname.setText("");
				txtlname.setText("");
				txtemail.setText("");
				txtcontactno.setText("");
				txtcnicenroll.setText("");
				txtpassword.setText("");
				txtconfirmpass.setText("");
				txtdob.setText("");
				txtareaaddress.setText("");
				rdbtnTeacher.setSelected(false);
				rdbtnStudent.setSelected(false);
				
			}
		});
		btnreset.setFont(new Font("Arial", Font.PLAIN, 15));
		btnreset.setBackground(new Color(153, 255, 255));
		btnreset.setBounds(341, 449, 116, 46);
		contentPane.add(btnreset);
		
		JButton btnregister = new JButton("Register");
		btnregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//get all the textfield values and check if every required textfield's value is entered
				String fname=txtfname.getText();
				String lname=txtlname.getText();
				String email=txtemail.getText();
				String contact=txtcontactno.getText();
				String password=txtpassword.getText();
				String confpassword=txtconfirmpass.getText();
				String address=txtareaaddress.getText().toString();
				String usertype=(rdbtnTeacher.isSelected()?"Teacher":"Student");
				String dob=txtdob.getText();
				String cnicEnroll=txtcnicenroll.getText();
				

				DatabaseAccessLayer dba=new DatabaseAccessLayer();
				
				dba.OpenConnection();
				
				if(fname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter First Name");
				}
				else if(!ValidationHelper.isString(fname))
				{
					JOptionPane.showMessageDialog(null, "First Name is Invlaid");
				}
				else if(lname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Last Name");
				}
				else if(!ValidationHelper.isString(lname))
				{
					JOptionPane.showMessageDialog(null, "Last Name is Invlaid");
				}
				else if(email.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Email Address");
				}
				else if(!ValidationHelper.isValidEmail(email))
				{
					JOptionPane.showMessageDialog(null, "Email is Invlaid");
				}
				else if(contact.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Contact Num");
				}
				else if(!ValidationHelper.isNumber(contact))
				{
					JOptionPane.showMessageDialog(null, "Invalid Contact Num");
				}
				else if(address.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Address");
				}
				else if(!ValidationHelper.isValidDate(dob))
				{
					JOptionPane.showMessageDialog(null, "Invalid Date of birth (yyy/MM/dd)");
				}
				else if(password.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Password");
				}
				else if(!ValidationHelper.isValidPassword(password))
				{
					JOptionPane.showMessageDialog(null, "Invalid Password! Password must contain Atleast 8 characters, one Digit,one Alphabet and one Special Character must be there to make password strong.");
				}
				else if(confpassword.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Confirm Password");
				}
				else if(cnicEnroll.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter CNIC/ Enrollment No");
				}
				else if(!dba.isUnique("Email", email))
				{
					JOptionPane.showMessageDialog(null, "Email already exists please try again");
				}
				else if(!password.equals(confpassword))
				{
					JOptionPane.showMessageDialog(null, "Password and Confirm Password are not equal");
				}
				else if(!dba.isUnique("CNICEnrollmentNo", cnicEnroll))
				{
					JOptionPane.showMessageDialog(null, "CNIC/Enrollment Number already exists please try again");
				}
				else
				{
					int response = dba.SaveUser(fname,lname,email,contact,password,dob,address,usertype,cnicEnroll);
					
					if(response==-1)
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "Ooops !!! Something went wrong. Try again please...");
					}
					else
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "User Created");
						
						LoginFrm.main(new String[] {});
						
						frame.dispose();
						
					}
				}
				
				dba.CloseConnection();
			}
		});
		btnregister.setFont(new Font("Arial", Font.PLAIN, 15));
		btnregister.setBackground(new Color(153, 255, 255));
		btnregister.setBounds(481, 449, 116, 46);
		contentPane.add(btnregister);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 433, 585, 17);
		contentPane.add(separator_1);
	}
}
