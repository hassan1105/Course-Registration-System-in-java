package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import databasehelper.DatabaseAccessLayer;
import model.CourseAssignment;
import model.User;
import java.awt.Color;
import java.awt.Toolkit;

public class RequestStatusFrm extends JFrame {

	public static User loggedInUser;
	private static RequestStatusFrm frame;
	private JPanel contentPane;
	private JTable table;
	public static String AdminOperation=null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new RequestStatusFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RequestStatusFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( Request Status Detail List)");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1049, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);


		JLabel label = new JLabel("Request Status List");
		label.setBackground(new Color(153, 255, 255));
		label.setFont(new Font("Tahoma", Font.BOLD, 31));
		contentPane.add(label, BorderLayout.NORTH);
		
		table = new JTable();//data,column);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
				int column=1;
				int row = table.getSelectedRow();
				
				String value=table.getModel().getValueAt(row, column).toString();
				String teacher=table.getModel().getValueAt(row, 0).toString();
				
				int result=JOptionPane.showConfirmDialog(null, "Are you sure you want to approve the selection");
				
				if(result==0)
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					dba.OpenConnection();

					int response ;
					
					if(loggedInUser.getUserType().equals("SuperAdmin"))
					{
						response = dba.ApproveRequest(loggedInUser.getUserType(),loggedInUser.getUser_ID(),value,teacher,AdminOperation);
					}
					else
					{
						response = dba.ApproveRequest(loggedInUser.getUserType(),loggedInUser.getUser_ID(),value,teacher,null);
					}
					
					if(response==1)
					{
						JOptionPane.showMessageDialog(null, "Request accepted successfully");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Ooops something went wrong. Please try again later");
					}
					dba.CloseConnection();
				}
				
				DisplayRequestList();
			}
		});
		
		if(loggedInUser.getUserType().equals("Teacher"))
		{
			table.setModel(new DefaultTableModel(new Object[][] {
				
			},
					new String[] {
							"TeacherID","CourseCode","Status","RequestDate"
					}));
		}
		else if(loggedInUser.getUserType().equals("Student"))
		{
			table.setModel(new DefaultTableModel(new Object[][] {
				
			},
					new String[] {
							"StudentID","CourseCode","Status","RequestDate"
					}));
		}
		else if(loggedInUser.getUserType().equals("SuperAdmin")&& AdminOperation.equals("Teacher"))
		{
			table.setModel(new DefaultTableModel(new Object[][] {
				
			},
					new String[] {
							"TeacherID","CourseCode","Status","RequestDate"
					}));
		}
		else if(loggedInUser.getUserType().equals("SuperAdmin")&& AdminOperation.equals("Student"))
		{
			table.setModel(new DefaultTableModel(new Object[][] {
				
			},
					new String[] {
							"StudentID","CourseCode","Status","RequestDate"
					}));
		}
		

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		DisplayRequestList();
	}

	private void DisplayRequestList() {
		// TODO Auto-generated method stub
		ArrayList<CourseAssignment> userlist = null;
		
		DatabaseAccessLayer dba=new DatabaseAccessLayer();
		dba.OpenConnection();

		if(loggedInUser.getUserType().equals("Teacher"))
		{
			userlist=dba.getRequestList("Teacher",loggedInUser.getUser_ID(),null);
		}
		else if(loggedInUser.getUserType().equals("Student")){
			userlist=dba.getRequestList("Student",loggedInUser.getUser_ID(),null);
		}
		else if(loggedInUser.getUserType().equals("SuperAdmin") ){
			userlist=dba.getRequestList("SuperAdmin",loggedInUser.getUser_ID(),AdminOperation);
		}
			
		
		DefaultTableModel model=(DefaultTableModel)table.getModel();		
		//clear jtable contents
		model.setRowCount(0);		
		Object[] row=new Object[5];
		
		for(int i=0;i<userlist.size();i++)
		{
			row[0]=userlist.get(i).getTeacherID();
			row[1]=userlist.get(i).getCourseID();
			row[2]=userlist.get(i).getStatus();
			row[3]=userlist.get(i).getAssignedDate();
			
			model.addRow(row);
		}
		
		dba.CloseConnection();
		
	}
}
