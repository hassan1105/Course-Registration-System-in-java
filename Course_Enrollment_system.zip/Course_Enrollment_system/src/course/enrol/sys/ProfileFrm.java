package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class ProfileFrm extends JFrame {

	private static ProfileFrm frame;
	private JPanel contentPane;
	private JTextField txtfname;
	private JTextField txtlname;
	private JTextField txtcontactno;
	private JTextField txtemail;
	private JTextField txtpassword;
	private JTextField txtdob;
	private JTextField txtcnicenroll;
	private JLabel lblusertype;
	private JTextArea txtareaAddress;
	
	public static User loggedInUser;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new ProfileFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProfileFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( Profile )");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 631, 494);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblProfile = new JLabel("Profile");
		lblProfile.setBackground(new Color(0, 204, 204));
		lblProfile.setHorizontalAlignment(SwingConstants.CENTER);
		lblProfile.setFont(new Font("Arial", Font.BOLD, 32));
		lblProfile.setBounds(175, 13, 243, 53);
		contentPane.add(lblProfile);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel lblYourProfileDetails = new JLabel("Your Profile Details are below:");
		lblYourProfileDetails.setFont(new Font("Arial", Font.PLAIN, 15));
		lblYourProfileDetails.setBounds(22, 79, 234, 17);
		contentPane.add(lblYourProfileDetails);
		
		JLabel label_2 = new JLabel("First Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(12, 109, 82, 16);
		contentPane.add(label_2);
		
		txtfname = new JTextField();
		txtfname.setEditable(false);
		txtfname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtfname.setColumns(10);
		txtfname.setBounds(12, 126, 273, 22);
		contentPane.add(txtfname);
		
		JLabel label_3 = new JLabel("Last Name");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(297, 109, 82, 16);
		contentPane.add(label_3);
		
		txtlname = new JTextField();
		txtlname.setEditable(false);
		txtlname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtlname.setColumns(10);
		txtlname.setBounds(297, 126, 299, 22);
		contentPane.add(txtlname);
		
		JLabel label_4 = new JLabel("Contact No");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(297, 169, 82, 16);
		contentPane.add(label_4);
		
		txtcontactno = new JTextField();
		txtcontactno.setEditable(false);
		txtcontactno.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtcontactno.setColumns(10);
		txtcontactno.setBounds(297, 186, 299, 22);
		contentPane.add(txtcontactno);
		
		txtemail = new JTextField();
		txtemail.setEditable(false);
		txtemail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtemail.setColumns(10);
		txtemail.setBounds(12, 186, 273, 22);
		contentPane.add(txtemail);
		
		JLabel label_5 = new JLabel("Email");
		label_5.setFont(new Font("Arial", Font.PLAIN, 15));
		label_5.setBounds(12, 169, 82, 16);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Password");
		label_6.setFont(new Font("Arial", Font.PLAIN, 15));
		label_6.setBounds(12, 221, 82, 16);
		contentPane.add(label_6);
		
		txtpassword = new JTextField();
		txtpassword.setEditable(false);
		txtpassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtpassword.setColumns(10);
		txtpassword.setBounds(13, 242, 273, 22);
		contentPane.add(txtpassword);
		
		JLabel label_8 = new JLabel("Address");
		label_8.setFont(new Font("Arial", Font.PLAIN, 15));
		label_8.setBounds(297, 277, 82, 16);
		contentPane.add(label_8);
		
		txtareaAddress = new JTextArea();
		txtareaAddress.setEditable(false);
		txtareaAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtareaAddress.setBounds(297, 295, 300, 53);
		contentPane.add(txtareaAddress);
		
		JLabel label_9 = new JLabel("DOB ( YYYY/MM/DD)");
		label_9.setFont(new Font("Arial", Font.PLAIN, 15));
		label_9.setBounds(22, 277, 185, 16);
		contentPane.add(label_9);
		
		txtdob = new JTextField();
		txtdob.setEditable(false);
		txtdob.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtdob.setColumns(10);
		txtdob.setBounds(12, 295, 273, 22);
		contentPane.add(txtdob);
		
		JLabel label_10 = new JLabel("User Type");
		label_10.setFont(new Font("Arial", Font.PLAIN, 15));
		label_10.setBounds(12, 330, 82, 16);
		contentPane.add(label_10);
		
		JLabel label_11 = new JLabel("CNIC/ Enrollment No");
		label_11.setFont(new Font("Arial", Font.PLAIN, 15));
		label_11.setBounds(298, 221, 158, 16);
		contentPane.add(label_11);
		
		txtcnicenroll = new JTextField();
		txtcnicenroll.setEditable(false);
		txtcnicenroll.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtcnicenroll.setColumns(10);
		txtcnicenroll.setBounds(297, 240, 299, 22);
		contentPane.add(txtcnicenroll);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 373, 585, 17);
		contentPane.add(separator_1);
		
		JButton button = new JButton("Close");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		button.setFont(new Font("Arial", Font.PLAIN, 15));
		button.setBackground(new Color(153, 255, 255));
		button.setBounds(207, 389, 116, 46);
		contentPane.add(button);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtfname.setEditable(true);
				txtlname.setEditable(true);
				txtemail.setEditable(true);
				txtcontactno.setEditable(true);
				txtpassword.setEditable(true);
				txtcnicenroll.setEditable(true);
				txtdob.setEditable(true);
				txtareaAddress.setEditable(true);
								
			}
		});
		btnEdit.setFont(new Font("Arial", Font.PLAIN, 15));
		btnEdit.setBackground(new Color(153, 255, 255));
		btnEdit.setBounds(341, 389, 116, 46);
		contentPane.add(btnEdit);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//get all the textfield values and check if every required textfield's value is entered
				loggedInUser.setAddress(txtareaAddress.getText().toString());
				loggedInUser.setCNICEnrollmentNo(txtcnicenroll.getText().toString());
				loggedInUser.setContactNo(txtcontactno.getText());
				loggedInUser.setDOB(Date.valueOf(txtdob.getText()));
				loggedInUser.setEmail(txtemail.getText());
				loggedInUser.setFirstName(txtfname.getText());
				loggedInUser.setLastName(txtlname.getText());
				loggedInUser.setPassword(txtpassword.getText());
				String Fname=txtfname.getText();
				String lname=txtlname.getText();
				String Password=txtpassword.getText();
				String email=txtemail.getText();
				String Dob=txtdob.getText();
				String contactno=txtcontactno.getText();
				DatabaseAccessLayer dba=new DatabaseAccessLayer();
				
				dba.OpenConnection();
				
				if(txtfname.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter First Name");
				}
				else if(!ValidationHelper.isString(Fname))
				{
					JOptionPane.showMessageDialog(null, "First Name is Invlaid");
				}
				else if(txtlname.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Last Name");
				}
				else if(!ValidationHelper.isString(lname))
				{
					JOptionPane.showMessageDialog(null, "Last Name is Invlaid");
				}
				else if(txtemail.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Email Address");
				}
				else if(!ValidationHelper.isValidEmail(email))
				{
					JOptionPane.showMessageDialog(null, "Email Formate is Invlaid");
				}
				else if(txtcontactno.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Contact Num");
				}
				else if(!ValidationHelper.isNumber(contactno))
				{
					JOptionPane.showMessageDialog(null, "Contact No. is Invlaid");
				}
				else if(txtareaAddress.getText().toString().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Address");
				} 
				else if(txtpassword.getText().toString().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Password");
				}
				else if(!ValidationHelper.isValidPassword(Password))
				{
					JOptionPane.showMessageDialog(null, "Password is too Weak try too use some number and special character");
				}
				else if(txtcnicenroll.getText().toString().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter CNIC/ Enrollment No");
				}
				else
				{
					int response = dba.UpdateUser(loggedInUser);
					
					if(response==-1)
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "Ooops !!! Something went wrong. Try again please...");
					}
					else
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "User Updated");
						
						displayModel();
					}
				}
				
				dba.CloseConnection();
				
			}
		});
		btnSave.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSave.setBackground(new Color(153, 255, 255));
		btnSave.setBounds(481, 389, 116, 46);
		contentPane.add(btnSave);
		
		lblusertype = new JLabel("New label");
		lblusertype.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblusertype.setBounds(106, 332, 138, 31);
		contentPane.add(lblusertype);
		
		displayModel();
	}

	private void displayModel() {
		// TODO Auto-generated method stub
		
		txtfname.setText(loggedInUser.getFirstName());
		txtlname.setText(loggedInUser.getLastName());
		txtcnicenroll.setText(loggedInUser.getCNICEnrollmentNo());
		txtcontactno.setText(loggedInUser.getContactNo());
		txtdob.setText(loggedInUser.getDOB().toString());
		txtemail.setText(loggedInUser.getEmail());
		txtpassword.setText(loggedInUser.getPassword());
		lblusertype.setText(loggedInUser.getUserType());
		txtareaAddress.setText(loggedInUser.getAddress());
	}

}
