package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.Course;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class DeleteCourse extends JFrame {

	private JPanel contentPane;
	private static DeleteCourse frame;
	private JTextField txtsearch;
	private JTextField txtname;
	private JTextField txtcoursecode;
	private JTextField txtcredithr;
	private JTextField txtaddedby;
	private JTextField txtdescription;
	private JTextField txtaddeddate;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new DeleteCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteCourse() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setBackground(new Color(0, 204, 204));
		setTitle("Course Enrollment System ( Delete Course )");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 627, 442);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCourseDeletion = new JLabel("Course Deletion");
		lblCourseDeletion.setHorizontalAlignment(SwingConstants.CENTER);
		lblCourseDeletion.setFont(new Font("Arial", Font.BOLD, 32));
		lblCourseDeletion.setBounds(142, 13, 333, 53);
		contentPane.add(lblCourseDeletion);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel label_1 = new JLabel("Search for course code");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(22, 97, 206, 16);
		contentPane.add(label_1);
		
		txtsearch = new JTextField();
		txtsearch.setColumns(10);
		txtsearch.setBounds(210, 94, 200, 22);
		contentPane.add(txtsearch);
		
		JButton button = new JButton("Search");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txtsearch.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Course Code first to search...");
				}
				else
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					Course model=dba.getCourseByCode(txtsearch.getText().toString());
							
					if(model!=null)
					{
						txtcoursecode.setText(model.getCourseCode());
						txtname.setText(model.getName());
						txtcredithr.setText(model.getCreditHrs());
						txtdescription.setText(model.getDescription());
						txtaddedby.setText(String.valueOf(model.getAddedBy()));
						txtaddeddate.setText(model.getAddedDate().toString());
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Invalid course code. Please try again");
					}
					dba.CloseConnection();
				}
				
			}
		});
		button.setFont(new Font("Arial", Font.PLAIN, 15));
		button.setBackground(new Color(153, 255, 255));
		button.setBounds(481, 79, 116, 46);
		contentPane.add(button);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 131, 585, 17);
		contentPane.add(separator_1);
		
		JLabel label_2 = new JLabel("Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(297, 148, 82, 16);
		contentPane.add(label_2);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(297, 165, 299, 22);
		contentPane.add(txtname);
		
		JLabel label_3 = new JLabel("Course Code");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(12, 148, 103, 16);
		contentPane.add(label_3);
		
		txtcoursecode = new JTextField();
		txtcoursecode.setColumns(10);
		txtcoursecode.setBounds(12, 165, 273, 22);
		contentPane.add(txtcoursecode);
		
		JLabel label_4 = new JLabel("Credit Hrs");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(12, 208, 82, 16);
		contentPane.add(label_4);
		
		txtcredithr = new JTextField();
		txtcredithr.setColumns(10);
		txtcredithr.setBounds(12, 225, 273, 22);
		contentPane.add(txtcredithr);
		
		JLabel label_5 = new JLabel("Added By");
		label_5.setFont(new Font("Arial", Font.PLAIN, 15));
		label_5.setBounds(13, 271, 82, 16);
		contentPane.add(label_5);
		
		txtaddedby = new JTextField();
		txtaddedby.setColumns(10);
		txtaddedby.setBounds(13, 288, 273, 22);
		contentPane.add(txtaddedby);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(12, 323, 585, 17);
		contentPane.add(separator_2);
		
		JLabel label_6 = new JLabel("Description");
		label_6.setFont(new Font("Arial", Font.PLAIN, 15));
		label_6.setBounds(297, 208, 82, 16);
		contentPane.add(label_6);
		
		txtdescription = new JTextField();
		txtdescription.setColumns(10);
		txtdescription.setBounds(297, 225, 299, 22);
		contentPane.add(txtdescription);
		
		JLabel label_7 = new JLabel("Register Date");
		label_7.setFont(new Font("Arial", Font.PLAIN, 15));
		label_7.setBounds(298, 271, 123, 16);
		contentPane.add(label_7);
		
		txtaddeddate = new JTextField();
		txtaddeddate.setColumns(10);
		txtaddeddate.setBounds(298, 288, 299, 22);
		contentPane.add(txtaddeddate);
		
		JButton button_1 = new JButton("Reset");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtsearch.setText("");
				txtcoursecode.setText("");
				txtname.setText("");
				txtcredithr.setText("");
				txtdescription.setText("");
				txtaddedby.setText("");
				txtaddeddate.setText("");
				
			}
		});
		button_1.setFont(new Font("Arial", Font.PLAIN, 15));
		button_1.setBackground(new Color(153, 255, 255));
		button_1.setBounds(341, 339, 116, 46);
		contentPane.add(button_1);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Course model;
				
				if(txtcoursecode.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course code cannot be empty");
				}
				else if(txtname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course Name cannot be empty");
				}
				else if(txtcredithr.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course credit hours cannot be empty");
				}
				else if(txtdescription.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Description details are missing");
				}
				else
				{
					model = new Course();					
					model.setCourseCode(txtcoursecode.getText());

					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					dba.OpenConnection();
					
					int response=dba.DeleteCourse(model);
					
					if(response!=-1)
					{
						JOptionPane.showMessageDialog(null, "Course has been Deleted successfully");
						dba.CloseConnection();
						frame.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Ooops! something went wrong please try again later");
					}
					
					dba.CloseConnection();
				}
				
			}
		});
		btnDelete.setFont(new Font("Arial", Font.PLAIN, 15));
		btnDelete.setBackground(new Color(153, 255, 255));
		btnDelete.setBounds(481, 339, 116, 46);
		contentPane.add(btnDelete);
	}

}
