package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import databasehelper.DatabaseAccessLayer;
import model.Course;
import model.User;
import java.awt.Color;

public class StudentRequestsFrm extends JFrame {

	public static User loggedInUser;
	private static StudentRequestsFrm frame;
	private JPanel contentPane;
	private JTable table;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new StudentRequestsFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentRequestsFrm() {

		setTitle("Course Enrollment System ( Students Signup Request List )");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1049, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		
		JLabel label = new JLabel("Student Signup Request List");
		label.setBackground(new Color(153, 255, 255));
		label.setFont(new Font("Tahoma", Font.BOLD, 31));
		contentPane.add(label, BorderLayout.NORTH);
		
		table = new JTable();//data,column);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
				int column=0;
				int row = table.getSelectedRow();
				
				String value=table.getModel().getValueAt(row, column).toString();
				
				int result=JOptionPane.showConfirmDialog(null, "Are you sure you want to approve the selected Student");
				
				if(result==0)
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					dba.OpenConnection();

					int response = dba.ApproveUserRequest(value);

					if(response==1)
					{
						JOptionPane.showMessageDialog(null, "User Approved Successfully");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Ooops something went wrong. Please try again later");
					}
					dba.CloseConnection();
				}
				
				DisplayStudentList();
			}
		});
		
		table.setModel(new DefaultTableModel(new Object[][] {
			
		},
				new String[] {
						"User_ID","FirstName","LastName","Email","ContactNo","UserType",
						"IsActive","RegisterDate","CNICEnrollmentNo","Password","DOB","Address"
				}));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		DisplayStudentList();
	}


	private void DisplayStudentList() {
		// TODO Auto-generated method stub
		ArrayList<User> userlist;
		
		DatabaseAccessLayer dba=new DatabaseAccessLayer();
		dba.OpenConnection();

		userlist=dba.getUserList("Student");
		DefaultTableModel model=(DefaultTableModel)table.getModel();		
		//clear jtable contents
		model.setRowCount(0);		
		Object[] row=new Object[13];
		
		for(int i=0;i<userlist.size();i++)
		{
			row[0]=userlist.get(i).getUser_ID();
			row[1]=userlist.get(i).getFirstName();
			row[2]=userlist.get(i).getLastName();
			row[3]=userlist.get(i).getEmail();
			row[4]=userlist.get(i).getContactNo();
			row[5]=userlist.get(i).getUserType();
			row[6]=userlist.get(i).isIsActive();
			row[7]=userlist.get(i).getRegisterDate();
			row[8]=userlist.get(i).getCNICEnrollmentNo();
			row[9]=userlist.get(i).getPassword();
			row[10]=userlist.get(i).getDOB();
			row[11]=userlist.get(i).getAddress();
			
			
			model.addRow(row);
		}
		
		dba.CloseConnection();
		
	}

}
