package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddStudentFrm extends JFrame {
	
	private JTextArea txtadress;
	private JPanel contentPane;
	private JTextField txtfname;
	private JTextField txtlname;
	private JTextField txtcontact;
	private JTextField txtemail;
	private JTextField txtpassword;
	private JTextField txtdob;
	private JTextField txtcnic;
	public static AddStudentFrm frame ;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new AddStudentFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddStudentFrm() {
		setTitle("Course Enrollment System ( Studentn Registeration Form)");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 629, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegisterNewStudent = new JLabel("Register New Student below");
		lblRegisterNewStudent.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegisterNewStudent.setFont(new Font("Arial", Font.BOLD, 32));
		lblRegisterNewStudent.setBounds(77, 13, 465, 53);
		contentPane.add(lblRegisterNewStudent);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel label_1 = new JLabel("First Name");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(12, 109, 82, 16);
		contentPane.add(label_1);
		
		txtfname = new JTextField();
		txtfname.setText((String) null);
		txtfname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtfname.setColumns(10);
		txtfname.setBounds(12, 126, 273, 22);
		contentPane.add(txtfname);
		
		JLabel label_2 = new JLabel("Last Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(297, 109, 82, 16);
		contentPane.add(label_2);
		
		txtlname = new JTextField();
		txtlname.setText((String) null);
		txtlname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtlname.setColumns(10);
		txtlname.setBounds(297, 126, 299, 22);
		contentPane.add(txtlname);
		
		JLabel label_3 = new JLabel("Contact No");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(297, 169, 82, 16);
		contentPane.add(label_3);
		
		txtcontact = new JTextField();
		txtcontact.setText((String) null);
		txtcontact.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtcontact.setColumns(10);
		txtcontact.setBounds(297, 186, 299, 22);
		contentPane.add(txtcontact);
		
		JLabel label_4 = new JLabel("Email");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(12, 169, 82, 16);
		contentPane.add(label_4);
		
		txtemail = new JTextField();
		txtemail.setText((String) null);
		txtemail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtemail.setColumns(10);
		txtemail.setBounds(12, 186, 273, 22);
		contentPane.add(txtemail);
		
		JLabel label_5 = new JLabel("Password");
		label_5.setFont(new Font("Arial", Font.PLAIN, 15));
		label_5.setBounds(12, 221, 82, 16);
		contentPane.add(label_5);
		
		txtpassword = new JTextField();
		txtpassword.setText((String) null);
		txtpassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtpassword.setColumns(10);
		txtpassword.setBounds(13, 242, 273, 22);
		contentPane.add(txtpassword);
		
		JLabel label_6 = new JLabel("DOB ( YYYY/MM/DD)");
		label_6.setFont(new Font("Arial", Font.PLAIN, 15));
		label_6.setBounds(22, 277, 185, 16);
		contentPane.add(label_6);
		
		txtdob = new JTextField();
		txtdob.setText((String) null);
		txtdob.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtdob.setColumns(10);
		txtdob.setBounds(12, 295, 273, 22);
		contentPane.add(txtdob);
		
		JLabel label_7 = new JLabel("User Type");
		label_7.setFont(new Font("Arial", Font.PLAIN, 15));
		label_7.setBounds(12, 330, 82, 16);
		contentPane.add(label_7);
		
		JLabel lblStudent = new JLabel("Student");
		lblStudent.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblStudent.setBounds(106, 330, 138, 31);
		contentPane.add(lblStudent);
		
		txtadress = new JTextArea();
		txtadress.setText((String) null);
		txtadress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtadress.setBounds(297, 295, 300, 53);
		contentPane.add(txtadress);
		
		JLabel label_9 = new JLabel("Address");
		label_9.setFont(new Font("Arial", Font.PLAIN, 15));
		label_9.setBounds(297, 277, 82, 16);
		contentPane.add(label_9);
		
		txtcnic = new JTextField();
		txtcnic.setText((String) null);
		txtcnic.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtcnic.setColumns(10);
		txtcnic.setBounds(297, 242, 299, 22);
		contentPane.add(txtcnic);
		
		JLabel label_10 = new JLabel("CNIC/ Enrollment No");
		label_10.setFont(new Font("Arial", Font.PLAIN, 15));
		label_10.setBounds(298, 221, 158, 16);
		contentPane.add(label_10);
		
		JButton button = new JButton("Reset");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtfname.setText("");
				txtlname.setText("");
				txtemail.setText("");
				txtcontact.setText("");
				txtdob.setText("");
				txtadress.setText("");
				txtpassword.setText("");
				txtcnic.setText("");
			
			}
		});
		button.setFont(new Font("Arial", Font.PLAIN, 15));
		button.setBackground(Color.WHITE);
		button.setBounds(341, 389, 116, 46);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Save");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//get all the textfield values and check if every required textfield's value is entered
				String fname=txtfname.getText();
				String lname=txtlname.getText();
				String email=txtemail.getText();
				String contact=txtcontact.getText();
				String password=txtpassword.getText();
				String address=txtadress.getText().toString();
				String usertype="Student";
				String dob=txtdob.getText();
				String cnicEnroll=txtcnic.getText();
				

				DatabaseAccessLayer dba=new DatabaseAccessLayer();
				
				dba.OpenConnection();
				
				if(fname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter First Name");
				}
				else if(!ValidationHelper.isString(fname))
				{
					JOptionPane.showMessageDialog(null, "First Name is Invlaid");
				}
				else if(lname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Last Name");
				}
				else if(!ValidationHelper.isString(lname))
				{
					JOptionPane.showMessageDialog(null, "Last Name is Invlaid");
				}
				else if(email.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Email Address");
				}
				else if(!ValidationHelper.isValidEmail(email))
				{
					JOptionPane.showMessageDialog(null, " Email Formate is Invlaid");
				}
				else if(contact.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Contact Num");
				}
				else if(!ValidationHelper.isNumber(contact))
				{
					JOptionPane.showMessageDialog(null, "Invlaid Contact number");
				}
				else if(address.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Address");
				} 
				else if(password.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Password");
				}
				else if(!ValidationHelper.isValidPassword(password))
				{
					JOptionPane.showMessageDialog(null, "Invalid Password! Password must contain Atleast 8 characters, one Digit,one Alphabet and one Special Character must be there to make password strong.");
				}
				else if(cnicEnroll.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter CNIC/ Enrollment No");
				}
				else if(!ValidationHelper.isNumber(cnicEnroll))
				{
					JOptionPane.showMessageDialog(null, " Enrollment is Invlaid");
				}
				else if(!dba.isUnique("Email", email))
				{
					JOptionPane.showMessageDialog(null, "Email already exists please try again");
				}
				
				else if(!dba.isUnique("CNICEnrollmentNo", cnicEnroll))
				{
					JOptionPane.showMessageDialog(null, "CNIC/Enrollment Number already exists please try again");
				}
				else
				{
					int response = dba.SaveUser(fname,lname,email,contact,password,dob,address,usertype,cnicEnroll);
					
					if(response==-1)
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "Ooops !!! Something went wrong. Try again please...");
					}
					else
					{
						dba.CloseConnection();
						JOptionPane.showMessageDialog(null, "Student has been registered successfully");
						
						frame.dispose();
						
					}
				}
				
				dba.CloseConnection();

			}
		});
		button_1.setFont(new Font("Arial", Font.PLAIN, 15));
		button_1.setBackground(Color.WHITE);
		button_1.setBounds(481, 389, 116, 46);
		contentPane.add(button_1);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 373, 585, 17);
		contentPane.add(separator_1);
	}

}
