package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.Course;
import model.User;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class RegisterCourseFrm extends JFrame {

	private JPanel contentPane;
	public static User LoggedInUser;
	public static RegisterCourseFrm frame;
	private JTextField txtsearch;
	private JTextField txtname;
	private JTextField txtcoursecode;
	private JTextField txtcredithrs;
	private JTextField txtdescription;
	private JTextField txtregisteredDate;
	private JTextField txtaddedby;
	private JButton btnViewAssignedTeacher ;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new RegisterCourseFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterCourseFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		
		if(LoggedInUser.getUserType().equals("Teacher"))
		{
			setTitle("Course Enrollment System ( Register Course )");
		}
		else
		{
			setTitle("Course Enrollment System ( Enroll Course )");
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 624, 509);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegisterCourse = new JLabel("Register Course");
		lblRegisterCourse.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegisterCourse.setFont(new Font("Arial", Font.BOLD, 32));
		lblRegisterCourse.setBounds(142, 13, 333, 53);
		contentPane.add(lblRegisterCourse);
		
		if(LoggedInUser.getUserType().equals("Teacher"))
		{
			lblRegisterCourse.setText("Register Course");
		}
		else
		{
			lblRegisterCourse.setText("Enroll Course");
		}
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		txtsearch = new JTextField();
		txtsearch.setColumns(10);
		txtsearch.setBounds(210, 94, 200, 22);
		contentPane.add(txtsearch);
		
		JLabel label_1 = new JLabel("Search for course code");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(22, 97, 206, 16);
		contentPane.add(label_1);
		
		JButton button = new JButton("Search");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txtsearch.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Course Code first to search...");
				}
				else
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					Course model=dba.getCourseByCode(txtsearch.getText().toString());
							
					if(model!=null)
					{
						txtcoursecode.setText(model.getCourseCode());
						txtname.setText(model.getName());
						txtcredithrs.setText(model.getCreditHrs());
						txtdescription.setText(model.getDescription());
						txtaddedby.setText(String.valueOf(model.getAddedBy()));
						txtregisteredDate.setText(model.getAddedDate().toString());
						btnViewAssignedTeacher.setEnabled(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Invalid course code. Please try again");
					}
					dba.CloseConnection();
				}
			}
		});
		button.setFont(new Font("Arial", Font.PLAIN, 15));
		button.setBackground(new Color(153, 255, 255));
		button.setBounds(481, 79, 116, 46);
		contentPane.add(button);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 131, 585, 17);
		contentPane.add(separator_1);
		
		txtname = new JTextField();
		txtname.setEditable(false);
		txtname.setColumns(10);
		txtname.setBounds(297, 165, 299, 22);
		contentPane.add(txtname);
		
		JLabel label_2 = new JLabel("Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(297, 148, 82, 16);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Course Code");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(12, 148, 103, 16);
		contentPane.add(label_3);
		
		txtcoursecode = new JTextField();
		txtcoursecode.setEditable(false);
		txtcoursecode.setColumns(10);
		txtcoursecode.setBounds(12, 165, 273, 22);
		contentPane.add(txtcoursecode);
		
		JLabel label_4 = new JLabel("Credit Hrs");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(12, 208, 82, 16);
		contentPane.add(label_4);
		
		txtcredithrs = new JTextField();
		txtcredithrs.setEditable(false);
		txtcredithrs.setColumns(10);
		txtcredithrs.setBounds(12, 225, 273, 22);
		contentPane.add(txtcredithrs);
		
		JLabel label_5 = new JLabel("Description");
		label_5.setFont(new Font("Arial", Font.PLAIN, 15));
		label_5.setBounds(297, 208, 82, 16);
		contentPane.add(label_5);
		
		txtdescription = new JTextField();
		txtdescription.setEditable(false);
		txtdescription.setColumns(10);
		txtdescription.setBounds(297, 225, 299, 22);
		contentPane.add(txtdescription);
		
		JLabel label_6 = new JLabel("Register Date");
		label_6.setFont(new Font("Arial", Font.PLAIN, 15));
		label_6.setBounds(298, 271, 123, 16);
		contentPane.add(label_6);
		
		txtregisteredDate = new JTextField();
		txtregisteredDate.setEditable(false);
		txtregisteredDate.setColumns(10);
		txtregisteredDate.setBounds(298, 288, 299, 22);
		contentPane.add(txtregisteredDate);
		
		JLabel label_7 = new JLabel("Added By");
		label_7.setFont(new Font("Arial", Font.PLAIN, 15));
		label_7.setBounds(13, 271, 82, 16);
		contentPane.add(label_7);
		
		txtaddedby = new JTextField();
		txtaddedby.setEditable(false);
		txtaddedby.setColumns(10);
		txtaddedby.setBounds(13, 288, 273, 22);
		contentPane.add(txtaddedby);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(12, 382, 585, 17);
		contentPane.add(separator_2);
		
		JButton button_1 = new JButton("Reset");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtsearch.setText("");
				txtcoursecode.setText("");
				txtname.setText("");
				txtcredithrs.setText("");
				txtdescription.setText("");
				txtaddedby.setText("");
				txtregisteredDate.setText("");
				btnViewAssignedTeacher.setEnabled(false);
			}
		});
		button_1.setFont(new Font("Arial", Font.PLAIN, 15));
		button_1.setBackground(new Color(153, 255, 255));
		button_1.setBounds(341, 398, 116, 46);
		contentPane.add(button_1);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(!txtcoursecode.getText().equals(""))
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					boolean response ;
					
					if(LoggedInUser.getUserType().equals("Teacher"))
					{
						response= dba.isCourseAlreadySelected(txtcoursecode.getText(),LoggedInUser.getUser_ID(),"Assignment");
					}
					else
					{
						response= dba.isCourseAlreadySelected(txtcoursecode.getText(),LoggedInUser.getUser_ID(),"Enrollment");
					}
					
					if(!response)
					{
						//send request for registeration here
						int responseResult ;
						
						if(LoggedInUser.getUserType().equals("Teacher"))
						{
							responseResult= dba.SendCourseRequest(txtcoursecode.getText(),LoggedInUser.getUser_ID(),"Assignment");
						}
						else
						{
							responseResult= dba.SendCourseRequest(txtcoursecode.getText(),LoggedInUser.getUser_ID(),"Enrollment");
						}
						
						if(responseResult==1)
						{
							if(LoggedInUser.getUserType().equals("Teacher"))
							{
								JOptionPane.showMessageDialog(null, "Congratulation couse registeration request has been sended to Admin.");
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Congratulation couse enrollment request has been sended to Admin.");
							}
							
							frame.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Ooops! something went wrong.");
						}
					}
					else
					{
						if(LoggedInUser.getUserType().equals("Teacher"))
						{
							JOptionPane.showMessageDialog(null, "You already have registered the selected Course.");
						}
						else
						{
							JOptionPane.showMessageDialog(null, "You already have enrolled the selected Course.");
						}
						
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Course should be selected first.");
				}
			}
		});
		btnRegister.setFont(new Font("Arial", Font.PLAIN, 15));
		btnRegister.setBackground(new Color(153, 255, 255));
		btnRegister.setBounds(481, 398, 116, 46);
		contentPane.add(btnRegister);
		
		btnViewAssignedTeacher = new JButton("View Enrolled Student");
		btnViewAssignedTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		if(LoggedInUser.getUserType().equals("Teacher"))
		{
			btnViewAssignedTeacher.setText("View Student Enrolled");
		}
		else
		{
			btnViewAssignedTeacher.setText("View Teacher Assigned");
		}
		
		btnViewAssignedTeacher.setEnabled(false);
		btnViewAssignedTeacher.setFont(new Font("Arial", Font.PLAIN, 15));
		btnViewAssignedTeacher.setBackground(new Color(153, 255, 255));
		btnViewAssignedTeacher.setBounds(341, 323, 256, 46);
		contentPane.add(btnViewAssignedTeacher);
	}

}
