package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.User;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
/*import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;*/
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JMenu;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JLabel;

public class DashBoardFrm extends JFrame {

	private static DashBoardFrm frame;
	private JPanel contentPane;
	public static User loggedInUser;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new DashBoardFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DashBoardFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( DashBoard )");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 842, 605);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(new Color(0, 204, 204));
		menuBar.setBackground(new Color(153, 255, 255));
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		mnNewMenu.setBackground(new Color(153, 255, 255));
		mnNewMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmProfile_1 = new JMenuItem("Profile");
		mntmProfile_1.setBackground(new Color(153, 255, 255));
		mntmProfile_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ProfileFrm.loggedInUser=loggedInUser;
				ProfileFrm.main(new String[] {});
				
			}
		});
		
		mnNewMenu.add(mntmProfile_1);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem mntmLogout = new JMenuItem("Logout");
		mntmLogout.setBackground(new Color(153, 255, 255));
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				loggedInUser = null;
				LoginFrm.main(new String[] {});
				
				frame.dispose();
			}
		});
		mnNewMenu.add(mntmLogout);
		
		JSeparator separator_1 = new JSeparator();
		mnNewMenu.add(separator_1);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setBackground(new Color(153, 255, 255));
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmExit);
		
		JMenu mnRequests = new JMenu("Requests");
		mnRequests.setBackground(new Color(153, 255, 255));
		menuBar.add(mnRequests);
		
		JMenu mnSignupRequests = new JMenu("Signup Requests");
		mnSignupRequests.setBackground(new Color(153, 255, 255));
		mnRequests.add(mnSignupRequests);
		
		JMenuItem mntmTeacher_1 = new JMenuItem("Teacher");
		mntmTeacher_1.setBackground(new Color(153, 255, 255));
		mntmTeacher_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				TeacherRequestsFrm.loggedInUser=loggedInUser;
				TeacherRequestsFrm.main(new String[] {});
				
			}
		});
		mnSignupRequests.add(mntmTeacher_1);
		
		JMenuItem mntmStudent_1 = new JMenuItem("Student");
		mntmStudent_1.setBackground(new Color(153, 255, 255));
		mntmStudent_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				

				StudentRequestsFrm.loggedInUser=loggedInUser;
				StudentRequestsFrm.main(new String[] {});
				
			}
		});
		mnSignupRequests.add(mntmStudent_1);
		
		JMenuItem mntmCourseEnrollRequests = new JMenuItem("Course Enroll Requests");
		mntmCourseEnrollRequests.setBackground(new Color(153, 255, 255));
		mntmCourseEnrollRequests.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RequestStatusFrm.loggedInUser=loggedInUser;
				RequestStatusFrm.AdminOperation="Student";
				RequestStatusFrm.main(new String[] {});
			}
		});
		mnRequests.add(mntmCourseEnrollRequests);
		
		JMenuItem mntmCourseRegisterRequests = new JMenuItem("Course Register Requests");
		mntmCourseRegisterRequests.setBackground(new Color(153, 255, 255));
		mntmCourseRegisterRequests.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				RequestStatusFrm.loggedInUser=loggedInUser;
				RequestStatusFrm.AdminOperation="Teacher";
				RequestStatusFrm.main(new String[] {});
				
			}
		});
		mnRequests.add(mntmCourseRegisterRequests);
		
		JMenu mnCourse = new JMenu("Course");
		mnCourse.setBackground(new Color(153, 255, 255));
		menuBar.add(mnCourse);
		
		JMenuItem mntmViewAllCourses = new JMenuItem("View All Courses");
		mntmViewAllCourses.setBackground(new Color(153, 255, 255));
		mntmViewAllCourses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ViewAllCourseList.main(new String[] {});
				
			}
		});
		mnCourse.add(mntmViewAllCourses);
		
		JSeparator separator_4 = new JSeparator();
		mnCourse.add(separator_4);
		
		JMenuItem mntmAddCourse = new JMenuItem("Add Course");
		mntmAddCourse.setBackground(new Color(153, 255, 255));
		mntmAddCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				AddNewCourse.LoggedInUser=loggedInUser;
				AddNewCourse.main(new String[] {});
				
			}
		});
		mnCourse.add(mntmAddCourse);
		
		JMenuItem mntmEditCourse = new JMenuItem("Edit Course");
		mntmEditCourse.setBackground(new Color(153, 255, 255));
		mntmEditCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EditCourse.main(new String[] {});
			}
		});
		mnCourse.add(mntmEditCourse);
		
		JMenuItem mntmDeleteCourse = new JMenuItem("Delete Course");
		mntmDeleteCourse.setBackground(new Color(153, 255, 255));
		mntmDeleteCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DeleteCourse.main(new String[] {});
			}
		});
		mnCourse.add(mntmDeleteCourse);
		
		JMenu mnTeacher = new JMenu("Teacher");
		mnTeacher.setBackground(new Color(153, 255, 255));
		menuBar.add(mnTeacher);
		
		JMenuItem mntmViewAllTeachers = new JMenuItem("View All Teachers");
		mntmViewAllTeachers.setBackground(new Color(153, 255, 255));
		mntmViewAllTeachers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				AllTeacherListFrm.loggedInUser=loggedInUser;
				AllTeacherListFrm.main(new String[] {});
				
			}
		});
		mnTeacher.add(mntmViewAllTeachers);
		
		JSeparator separator_2 = new JSeparator();
		mnTeacher.add(separator_2);
		
		JMenuItem mntmAddTeacher = new JMenuItem("Add Teacher");
		mntmAddTeacher.setBackground(new Color(153, 255, 255));
		mntmAddTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				AddTeacherFrm.main(new String[] {});
				
			}
		});
		mnTeacher.add(mntmAddTeacher);
		
		JMenuItem mntmEditTeacher = new JMenuItem("Edit Teacher");
		mntmEditTeacher.setBackground(new Color(153, 255, 255));
		mntmEditTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				EditDeleteTeacherFrm.Operation = "Edit";
				EditDeleteTeacherFrm.main(new String[] {});
				
			}
		});
		mnTeacher.add(mntmEditTeacher);
		
		JMenuItem mntmDeleteTeacher = new JMenuItem("Delete Teacher");
		mntmDeleteTeacher.setBackground(new Color(153, 255, 255));
		mntmDeleteTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				EditDeleteTeacherFrm.Operation = "Delete";
				EditDeleteTeacherFrm.main(new String[] {});
				
			}
		});
		mnTeacher.add(mntmDeleteTeacher);
		
		JMenu mnStudent = new JMenu("Student");
		mnStudent.setBackground(new Color(153, 255, 255));
		menuBar.add(mnStudent);
		
		JMenuItem mntmViewAllStudent = new JMenuItem("View All Student");
		mntmViewAllStudent.setBackground(new Color(153, 255, 255));
		mntmViewAllStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				AllStudentListFrm.loggedInUser=loggedInUser;
				AllStudentListFrm.main(new String[] {});
				
			}
		});
		mnStudent.add(mntmViewAllStudent);
		
		JSeparator separator_5 = new JSeparator();
		mnStudent.add(separator_5);
		
		JMenuItem mntmAddStudent = new JMenuItem("Add Student");
		mntmAddStudent.setBackground(new Color(153, 255, 255));
		mntmAddStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				AddStudentFrm.main(new String[] {});
			}
		});
		mnStudent.add(mntmAddStudent);
		
		JMenuItem mntmEditStudent = new JMenuItem("Edit Student");
		mntmEditStudent.setBackground(new Color(153, 255, 255));
		mntmEditStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				EditDeleteStudentFrm.Operation = "Edit";
				EditDeleteStudentFrm.main(new String[] {});
				
				
			}
		});
		mnStudent.add(mntmEditStudent);
		
		JMenuItem mntmDeleteStudent = new JMenuItem("Delete Student");
		mntmDeleteStudent.setBackground(new Color(153, 255, 255));
		mntmDeleteStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				EditDeleteStudentFrm.Operation = "Delete";
				EditDeleteStudentFrm.main(new String[] {});
				
				
			}
		});
		mnStudent.add(mntmDeleteStudent);
		
		JLabel lblAboutUs = new JLabel("about us");
		menuBar.add(lblAboutUs);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
}
