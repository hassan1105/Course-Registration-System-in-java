package course.enrol.sys;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import databasehelper.DatabaseAccessLayer;
import model.Course;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;

import validationhelper.ValidationHelper;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class EditCourse extends JFrame {

	private JPanel contentPane;
	private static EditCourse frame;
	private JTextField txtcoursecode;
	private JTextField txtname;
	private JTextField txtcredithr;
	private JTextField txtdescription;
	private JTextField txtsearch;
	private JTextField txtaddeddate;
	private JTextField txtaddedby;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new EditCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditCourse() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Hassan\\Documents\\bahria logo.jpg"));
		setTitle("Course Enrollment System ( Edit Course )");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 631, 441);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCourseModification = new JLabel("Course Modification");
		lblCourseModification.setHorizontalAlignment(SwingConstants.CENTER);
		lblCourseModification.setFont(new Font("Arial", Font.BOLD, 32));
		lblCourseModification.setBounds(142, 13, 333, 53);
		contentPane.add(lblCourseModification);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 67, 585, 17);
		contentPane.add(separator);
		
		JLabel label_1 = new JLabel("Course Code");
		label_1.setFont(new Font("Arial", Font.PLAIN, 15));
		label_1.setBounds(12, 148, 103, 16);
		contentPane.add(label_1);
		
		txtcoursecode = new JTextField();
		txtcoursecode.setColumns(10);
		txtcoursecode.setBounds(12, 165, 273, 22);
		contentPane.add(txtcoursecode);
		
		JLabel label_2 = new JLabel("Name");
		label_2.setFont(new Font("Arial", Font.PLAIN, 15));
		label_2.setBounds(297, 148, 82, 16);
		contentPane.add(label_2);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(297, 165, 299, 22);
		contentPane.add(txtname);
		
		txtcredithr = new JTextField();
		txtcredithr.setColumns(10);
		txtcredithr.setBounds(12, 225, 273, 22);
		contentPane.add(txtcredithr);
		
		JLabel label_3 = new JLabel("Credit Hrs");
		label_3.setFont(new Font("Arial", Font.PLAIN, 15));
		label_3.setBounds(12, 208, 82, 16);
		contentPane.add(label_3);
		
		txtdescription = new JTextField();
		txtdescription.setColumns(10);
		txtdescription.setBounds(297, 225, 299, 22);
		contentPane.add(txtdescription);
		
		JLabel label_4 = new JLabel("Description");
		label_4.setFont(new Font("Arial", Font.PLAIN, 15));
		label_4.setBounds(297, 208, 82, 16);
		contentPane.add(label_4);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 323, 585, 17);
		contentPane.add(separator_1);
		
		JButton button = new JButton("Reset");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtsearch.setText("");
				txtcoursecode.setText("");
				txtname.setText("");
				txtcredithr.setText("");
				txtdescription.setText("");
				txtaddedby.setText("");
				txtaddeddate.setText("");
				
			}
		});
		
		button.setFont(new Font("Arial", Font.PLAIN, 15));
		button.setBackground(new Color(153, 255, 255));
		button.setBounds(341, 339, 116, 46);
		contentPane.add(button);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Course model;
				String coursename=txtname.getText();
				String creditHrs=txtcredithr.getText();
				if(txtcoursecode.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course code cannot be empty");
				}
				else if(txtname.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course Name cannot be empty");
				}
				else if(!ValidationHelper.isString(coursename))
				{
					JOptionPane.showMessageDialog(null, "Course Name is Invalid");
				}
				else if(txtcredithr.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Course credit hours cannot be empty");
				}
				else if(!ValidationHelper.isNumber(creditHrs))
				{
					JOptionPane.showMessageDialog(null, "Credit Hours must be a Number");
				}
				else if(txtdescription.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Description details are missing");
				}
				else
				{
					model = new Course();
					
					model.setCourseCode(txtcoursecode.getText());
					model.setName(txtname.getText());
					model.setCreditHrs(txtcredithr.getText());
					model.setDescription(txtdescription.getText());
					
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					int response=dba.EditCourse(model);
					
					if(response!=-1)
					{
						JOptionPane.showMessageDialog(null, "Course has been Updated successfully");
						dba.CloseConnection();
						frame.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Ooops! something went wrong please try again later");
					}
					
					dba.CloseConnection();
				}
			}
		});
		btnUpdate.setFont(new Font("Arial", Font.PLAIN, 15));
		btnUpdate.setBackground(new Color(153, 255, 255));
		btnUpdate.setBounds(481, 339, 116, 46);
		contentPane.add(btnUpdate);
		
		JLabel lblSearchForCourse = new JLabel("Search for course code");
		lblSearchForCourse.setFont(new Font("Arial", Font.PLAIN, 15));
		lblSearchForCourse.setBounds(22, 97, 206, 16);
		contentPane.add(lblSearchForCourse);
		
		txtsearch = new JTextField();
		txtsearch.setColumns(10);
		txtsearch.setBounds(210, 94, 200, 22);
		contentPane.add(txtsearch);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(12, 131, 585, 17);
		contentPane.add(separator_2);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txtsearch.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Course Code first to search...");
				}
				else
				{
					DatabaseAccessLayer dba=new DatabaseAccessLayer();
					
					dba.OpenConnection();
					
					Course model=dba.getCourseByCode(txtsearch.getText().toString());
							
					if(model!=null)
					{
						txtcoursecode.setText(model.getCourseCode());
						txtname.setText(model.getName());
						txtcredithr.setText(model.getCreditHrs());
						txtdescription.setText(model.getDescription());
						txtaddedby.setText(String.valueOf(model.getAddedBy()));
						txtaddeddate.setText(model.getAddedDate().toString());
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Invalid course code. Please try again");
					}
					dba.CloseConnection();
				}
				
			}
		});
		btnSearch.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSearch.setBackground(new Color(153, 255, 255));
		btnSearch.setBounds(481, 79, 116, 46);
		contentPane.add(btnSearch);
		
		txtaddeddate = new JTextField();
		txtaddeddate.setColumns(10);
		txtaddeddate.setBounds(298, 288, 299, 22);
		contentPane.add(txtaddeddate);
		
		JLabel lblRegisterDate = new JLabel("Register Date");
		lblRegisterDate.setFont(new Font("Arial", Font.PLAIN, 15));
		lblRegisterDate.setBounds(298, 271, 123, 16);
		contentPane.add(lblRegisterDate);
		
		txtaddedby = new JTextField();
		txtaddedby.setColumns(10);
		txtaddedby.setBounds(13, 288, 273, 22);
		contentPane.add(txtaddedby);
		
		JLabel lblAddedBy = new JLabel("Added By");
		lblAddedBy.setFont(new Font("Arial", Font.PLAIN, 15));
		lblAddedBy.setBounds(13, 271, 82, 16);
		contentPane.add(lblAddedBy);
	}
}
