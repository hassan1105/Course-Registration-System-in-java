package model;

import java.sql.Date;

public class CourseEnrollment {

	private int StudentID;
	private String CourseID;
	private String Status;
	private Date EnrollmentDate;
	public CourseEnrollment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseEnrollment(int studentID, String courseID, String status, Date enrollmentDate) {
		super();
		StudentID = studentID;
		CourseID = courseID;
		Status = status;
		EnrollmentDate = enrollmentDate;
	}
	public int getStudentID() {
		return StudentID;
	}
	public void setStudentID(int studentID) {
		StudentID = studentID;
	}
	public String getCourseID() {
		return CourseID;
	}
	public void setCourseID(String courseID) {
		CourseID = courseID;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Date getEnrollmentDate() {
		return EnrollmentDate;
	}
	public void setEnrollmentDate(Date enrollmentDate) {
		EnrollmentDate = enrollmentDate;
	}
	
	
}
