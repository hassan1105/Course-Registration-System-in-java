package model;

import java.sql.Date;

public class Course {

	private String CourseCode;
	private String Name;
	private String CreditHrs;
	private String Description;
	private int AddedBy;
	private Date AddedDate;
	
	public Course()
	{
	
	}
	
	public Course(String CourseCode,String Name,String CreditHrs,String Description,int AddedBy,Date AddedDate)
	{
		this.CourseCode =CourseCode;
		this.Name=Name;
		this.CreditHrs=CreditHrs;
		this.Description=Description;
		this.AddedBy=AddedBy;
		this.AddedDate=AddedDate;
		
	}

	public String getCourseCode() {
		return CourseCode;
	}

	public void setCourseCode(String courseCode) {
		CourseCode = courseCode;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getCreditHrs() {
		return CreditHrs;
	}

	public void setCreditHrs(String creditHrs) {
		CreditHrs = creditHrs;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public int getAddedBy() {
		return AddedBy;
	}

	public void setAddedBy(int addedBy) {
		AddedBy = addedBy;
	}

	public Date getAddedDate() {
		return AddedDate;
	}

	public void setAddedDate(Date addedDate) {
		AddedDate = addedDate;
	}
	
	
}
