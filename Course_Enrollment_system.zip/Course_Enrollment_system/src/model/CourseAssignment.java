package model;

import java.sql.Date;

public class CourseAssignment {

	private int TeacherID;
	private String CourseID;
	private String Status;
	private Date AssignedDate;
	public CourseAssignment(int teacherID, String courseID, String status, Date assignedDate) {
		super();
		TeacherID = teacherID;
		CourseID = courseID;
		Status = status;
		AssignedDate = assignedDate;
	}
	public CourseAssignment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTeacherID() {
		return TeacherID;
	}
	public void setTeacherID(int teacherID) {
		TeacherID = teacherID;
	}
	public String getCourseID() {
		return CourseID;
	}
	public void setCourseID(String courseID) {
		CourseID = courseID;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Date getAssignedDate() {
		return AssignedDate;
	}
	public void setAssignedDate(Date assignedDate) {
		AssignedDate = assignedDate;
	}
	
	
}
