package model;

import java.util.Date;

public class User {

	private int User_ID;
	private String FirstName;
	private String LastName;
	private String Email;
	private String ContactNo;
	private String UserType;
	private boolean IsActive;
	private Date RegisterDate;
	private String CNICEnrollmentNo;
	private String Password;
	private Date DOB;
	private String Address;
	
	public User() {
	}
	
	public User(int user_ID, String firstName, String lastName, String email, String contactNo, String userType,
			boolean isActive, Date registerDate, String cnicEnrollmentNo,String password,Date dob,String address) {
		super();
		User_ID = user_ID;
		FirstName = firstName;
		LastName = lastName;
		Email = email;
		ContactNo = contactNo;
		UserType = userType;
		IsActive = isActive;
		RegisterDate = registerDate;
		CNICEnrollmentNo = cnicEnrollmentNo;
		Password=password;
		DOB=dob;
		Address=address;
	}
	public int getUser_ID() {
		return User_ID;
	}
	public void setUser_ID(int user_ID) {
		User_ID = user_ID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getContactNo() {
		return ContactNo;
	}
	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public boolean isIsActive() {
		return IsActive;
	}
	public void setIsActive(boolean isActive) {
		IsActive = isActive;
	}
	public Date getRegisterDate() {
		return RegisterDate;
	}
	public void setRegisterDate(Date registerDate) {
		RegisterDate = registerDate;
	}

	public String getCNICEnrollmentNo() {
		return CNICEnrollmentNo;
	}

	public void setCNICEnrollmentNo(String cNICEnrollmentNo) {
		CNICEnrollmentNo = cNICEnrollmentNo;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
	
	
}
